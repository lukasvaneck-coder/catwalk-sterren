// Allow pending Windows native handle cleanup before vinext terminates Node.
// Keep the original exit code, including every build failure.
const exit = process.exit.bind(process);
if (process.platform === 'win32') {
  process.exit = (code) => {
    setTimeout(() => exit(code), 250);
  };
}
process.argv = [process.argv[0], 'vinext', 'build'];
await import('../node_modules/vinext/dist/cli.js');

'use client';
import { Button } from '@/components/ui/button';
import {
  gardenItems,
  playgroundItems,
  type NeighborhoodSave,
} from '@/lib/neighborhood';
export function Decoration({ index }: { index: number }) {
  return (
    <span
      className="decoration-sprite"
      style={{
        backgroundPosition: `${(index % 3) * 50}% ${Math.floor(index / 3) * 100}%`,
      }}
    />
  );
}
export function NeighborhoodBuilder({
  mission,
  onUpdate,
  onMission,
  onHome,
}: {
  mission: NeighborhoodSave;
  onUpdate: (p: Partial<NeighborhoodSave>) => void;
  onMission: () => void;
  onHome: () => void;
}) {
  return (
    <section className="adventure-panel">
      <p className="eyebrow">JOUW EIGEN PLEK</p>
      <h1>Maak de buurt gezellig</h1>
      {!mission.completed ? (
        <div className="mission-intro">
          <span className="mission-large-icon">🌱</span>
          <h2>Een cadeautje voor je eerste avontuur</h2>
          <p>
            Vind je schooltas en help in de klas. Daarna mag je hier een
            voortuin en een speelplek kiezen.
          </p>
          <Button className="primary" onClick={onMission}>
            Naar mijn avontuur →
          </Button>
        </div>
      ) : (
        <>
          <p>
            Kies iets voor je voortuin en het grasveld. Je mag je keuze altijd
            veranderen.
          </p>
          {(['garden', 'playground'] as const).map((slot) => (
            <section className="build-section" key={slot}>
              <h2>{slot === 'garden' ? 'Mijn voortuin' : 'Onze speelplek'}</h2>
              <div className="build-choices">
                {(slot === 'garden' ? gardenItems : playgroundItems).map(
                  (item) => (
                    <Button
                      key={item.id}
                      className={`build-choice ${mission[slot] === item.id ? 'selected' : ''}`}
                      aria-pressed={mission[slot] === item.id}
                      onClick={() => onUpdate({ [slot]: item.id })}
                    >
                      <Decoration index={item.index} />
                      <strong>{item.name}</strong>
                      <small>
                        {mission[slot] === item.id
                          ? '✓ Staat in je buurt'
                          : 'Hier neerzetten'}
                      </small>
                    </Button>
                  ),
                )}
              </div>
              <Button
                className="soft"
                disabled={mission[slot] === 'none'}
                onClick={() => onUpdate({ [slot]: 'none' })}
              >
                Plek weer leegmaken
              </Button>
            </section>
          ))}
          <p className="mission-feedback" role="status">
            {mission.garden !== 'none' || mission.playground !== 'none'
              ? 'Je keuze staat in jouw buurt!'
              : 'De plekken zijn klaar om in te richten.'}
          </p>
          <Button className="primary" onClick={onHome}>
            Bekijk mijn buurt →
          </Button>
        </>
      )}
    </section>
  );
}

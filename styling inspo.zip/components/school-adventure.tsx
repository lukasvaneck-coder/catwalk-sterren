'use client';
import { BedroomWalk } from './bedroom-walk';
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, type AvatarLook } from './avatar';
import {
  crossedPuddle,
  jumpHeight,
  puddles,
  schoolAnswers,
  type NeighborhoodSave,
} from '@/lib/neighborhood';
function speak(text: string) {
  if ('speechSynthesis' in window) {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'nl-NL';
    u.rate = 0.88;
    speechSynthesis.speak(u);
  }
}
export function SchoolRun({
  look,
  group,
  onFinish,
}: {
  look: AvatarLook;
  group: 3 | 5;
  onFinish: () => void;
}) {
  const [view, setView] = useState({ travel: 0, height: 0 }),
    [active, setActive] = useState(false),
    [message, setMessage] = useState('Spring over de plassen op de stoep.'),
    [paused, setPaused] = useState(false);
  const state = useRef({
      travel: 0,
      clock: 0,
      jump: -10,
      checkpoint: 0,
      active: false,
      paused: false,
      done: false,
    }),
    finish = useRef(onFinish);
  finish.current = onFinish;
  function jump() {
    if (
      state.current.active &&
      !state.current.paused &&
      state.current.clock - state.current.jump >= 0.95
    )
      state.current.jump = state.current.clock;
  }
  useEffect(() => {
    let frame: number,
      last = 0;
    function tick(t: number) {
      const dt = Math.min((t - last) / 1000, 0.035);
      last = t;
      const s = state.current;
      if (s.active && !s.paused && !s.done) {
        s.clock += dt;
        const next = s.travel + dt * (group === 3 ? 90 : 120),
          height = jumpHeight(s.clock - s.jump);
        if (crossedPuddle(s.travel, next, height)) {
          s.active = false;
          s.travel = s.checkpoint;
          s.jump = -10;
          setActive(false);
          setMessage(
            'Spetter! Probeer dit stukje nog eens. Je bent je spullen niet kwijt.',
          );
        } else {
          s.travel = next;
          for (const p of puddles) if (next > p + 50) s.checkpoint = p + 50;
          if (next >= 1250) {
            s.done = true;
            finish.current();
          }
        }
        setView({ travel: s.travel, height });
      }
      frame = requestAnimationFrame(tick);
    }
    function key(e: KeyboardEvent) {
      if (
        state.current.active &&
        !state.current.paused &&
        (e.code === 'Space' || e.code === 'ArrowUp')
      ) {
        e.preventDefault();
        if (!e.repeat) jump();
      }
    }
    function visibility() {
      if (document.hidden) {
        state.current.paused = true;
        setPaused(true);
      }
    }
    window.addEventListener('keydown', key);
    document.addEventListener('visibilitychange', visibility);
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('keydown', key);
      document.removeEventListener('visibilitychange', visibility);
    };
  }, [group]);
  return (
    <>
      <div className="mission-instruction">
        <p>{message}</p>
        <Button
          className="soft"
          onClick={() =>
            speak(
              'Je loopt vanzelf. Druk op springen of op de spatiebalk als je vlak voor een plas bent. Je mag zo vaak proberen als je wilt.',
            )
          }
        >
          🔊 Uitleg
        </Button>
      </div>
      <div className="school-run" aria-label="Springparcours naar school">
        <div
          className="run-scenery"
          style={{ backgroundPosition: `${-view.travel / 2}px center` }}
        />
        <div className="run-distance">
          🏫 {Math.min(100, Math.floor((view.travel / 1250) * 100))}%
        </div>
        <div className="run-player" style={{ bottom: `${53 + view.height}px` }}>
          <Avatar look={look} compact />
        </div>
        {puddles.map((p, i) => (
          <span
            key={p}
            className="run-puddle"
            style={{ left: `${23 + (p - view.travel) / 6}%` }}
            aria-label={`Plas ${i + 1}`}
          >
            💦
          </span>
        ))}
        <div className="run-sidewalk" />
        {(!active || paused) && (
          <div className="run-overlay">
            <Button
              className="primary"
              onClick={() => {
                state.current.active = true;
                state.current.paused = false;
                setActive(true);
                setPaused(false);
                setMessage('Kijk vooruit… en spring!');
              }}
            >
              {paused
                ? 'Verder lopen ▶'
                : view.travel > 0
                  ? 'Nog eens proberen ▶'
                  : 'Op naar school! ▶'}
            </Button>
          </div>
        )}
      </div>
      <div className="mission-actions">
        <Button
          className="primary jump-button"
          disabled={!active || paused}
          onPointerDown={(e) => {
            e.preventDefault();
            jump();
          }}
          onClick={(e) => {
            if (e.detail === 0) jump();
          }}
        >
          Spring! ↑
        </Button>
        <Button
          className="soft"
          disabled={!active}
          onClick={() => {
            const next = !state.current.paused;
            state.current.paused = next;
            setPaused(next);
          }}
        >
          {paused ? '▶ Verder' : 'Ⅱ Pauze'}
        </Button>
      </div>
      <p className="hint">Tik op Spring! of gebruik spatie / pijltje omhoog.</p>
    </>
  );
}
function Classroom({
  group,
  onFinish,
}: {
  group: 3 | 5;
  onFinish: () => void;
}) {
  const [step, setStep] = useState(0),
    [chosen, setChosen] = useState<number[]>([]),
    [feedback, setFeedback] = useState(''),
    [counts, setCounts] = useState<number[]>(
      Array(group === 3 ? 3 : 4).fill(0),
    );
  const answer = schoolAnswers(group);
  const letters =
    group === 3 ? ['s', 'a', 't'] : ['o', 'l', 's', 'o', 'h', 'c'];
  const word = chosen.map((i) => letters[i]).join('');
  const correct = counts.every((n) => n === answer.each);
  return (
    <div className="classroom">
      <p className="eyebrow">
        GROEP {group} · OPDRACHT {step + 1} VAN 2
      </p>
      {step === 0 ? (
        <>
          <h2>Een kaartje voor {group === 3 ? 'je tas' : 'de school'}</h2>
          <div className="word-picture">{group === 3 ? '🎒' : '🏫'}</div>
          <p>
            Maak het woord {group === 3 ? 'tas' : 'school'}. Kies de letters in
            de juiste volgorde.
          </p>
          <div className="word-slots" aria-live="polite">
            {word || '…'}
          </div>
          <div className="letter-bank">
            {letters.map((l, i) => (
              <Button
                key={i}
                className="letter-tile"
                disabled={chosen.includes(i)}
                onClick={() => setChosen((c) => [...c, i])}
              >
                {l}
              </Button>
            ))}
          </div>
          <div className="mission-actions">
            <Button
              className="soft"
              onClick={() => {
                setChosen([]);
                setFeedback('');
              }}
            >
              ↶ Opnieuw
            </Button>
            <Button
              className="primary"
              disabled={chosen.length !== letters.length}
              onClick={() => {
                if (word === answer.word) {
                  setStep(1);
                  setFeedback('');
                } else
                  setFeedback(
                    'Bijna! Luister naar het woord en probeer de volgorde nog eens.',
                  );
              }}
            >
              Klaar ✓
            </Button>
            <Button className="soft" onClick={() => speak(answer.word)}>
              🔊 Het woord
            </Button>
          </div>
        </>
      ) : (
        <>
          <h2>Help het fruit verdelen</h2>
          <p>
            Geef elk van de {answer.plates} bordjes{' '}
            <strong>{answer.each} appels</strong>. Tik op een bord om een appel
            erbij te leggen.
          </p>
          <div className="fruit-plates">
            {counts.map((n, i) => (
              <div className="fruit-place" key={i}>
                <Button
                  className="fruit-plate"
                  aria-label={`Bord ${i + 1}: ${n} appels, voeg er een toe`}
                  onClick={() => {
                    setCounts((c) =>
                      c.map((v, j) => (j === i ? Math.min(5, v + 1) : v)),
                    );
                    setFeedback('');
                  }}
                >
                  {n ? '🍎'.repeat(n) : '＋'}
                </Button>
                <Button
                  className="soft"
                  disabled={!n}
                  onClick={() =>
                    setCounts((c) =>
                      c.map((v, j) => (j === i ? Math.max(0, v - 1) : v)),
                    )
                  }
                >
                  − Eentje terug
                </Button>
              </div>
            ))}
          </div>
          <p className="fruit-total">
            Samen {counts.reduce((a, b) => a + b, 0)} appels
          </p>
          <Button
            className="primary"
            onClick={() => {
              if (correct) onFinish();
              else
                setFeedback(
                  `Kijk nog even: op ieder bord horen ${answer.each} appels.`,
                );
            }}
          >
            Iedereen heeft genoeg ✓
          </Button>
        </>
      )}
      <p className="mission-feedback" role="status">
        {feedback}
      </p>
    </div>
  );
}
export function SchoolAdventure({
  look,
  mission,
  onUpdate,
  onClaim,
  onBuild,
  onHome,
}: {
  look: AvatarLook;
  mission: NeighborhoodSave;
  onUpdate: (patch: Partial<NeighborhoodSave>) => void;
  onClaim: () => void;
  onBuild: () => void;
  onHome: () => void;
}) {
  return (
    <section
      className={`adventure-panel immersive-adventure phase-${mission.phase}`}
    >
      {mission.phase === 'intro' ? (
        <div className="mission-intro">
          <span className="mission-large-icon">🎒</span>
          <h2>Een nieuwe schooldag!</h2>
          <p>
            Je bent aangekleed en klaar om te gaan. Maar… waar is je schooltas?
            Zoek thuis, pak je spullen en ga op avontuur naar school.
          </p>
          <fieldset>
            <legend>Welke klas kies je?</legend>
            {[3, 5].map((g) => (
              <Button
                key={g}
                className={`soft ${mission.group === g ? 'selected' : ''}`}
                aria-pressed={mission.group === g}
                onClick={() => onUpdate({ group: g as 3 | 5 })}
              >
                Groep {g}
              </Button>
            ))}
          </fieldset>
          <Button
            className="primary"
            onClick={() => onUpdate({ phase: 'search' })}
          >
            Zoek de schooltas →
          </Button>
          <Button
            className="soft"
            onClick={() =>
              speak(
                'Waar is je schooltas? Zoek eerst het briefje op het bureau. Daarna kun je je tas inpakken en naar school gaan.',
              )
            }
          >
            🔊 Vertel het verhaal
          </Button>
        </div>
      ) : mission.phase === 'search' || mission.phase === 'pack' ? (
        <BedroomWalk
          look={look}
          group={mission.group}
          packing={mission.phase === 'pack'}
          onPack={() => onUpdate({ phase: 'pack' })}
          onLeave={() => onUpdate({ phase: 'journey' })}
        />
      ) : mission.phase === 'journey' ? (
        <SchoolRun
          group={mission.group}
          look={look}
          onFinish={() => onUpdate({ phase: 'school' })}
        />
      ) : mission.phase === 'school' ? (
        <Classroom
          group={mission.group}
          onFinish={() => onUpdate({ phase: 'reward' })}
        />
      ) : mission.phase === 'reward' ? (
        <div className="mission-intro">
          <span className="mission-large-icon">🌟</span>
          <h2>Wat een fijne schooldag!</h2>
          <p>
            {mission.completed
              ? 'Je hebt het avontuur nog een keer uitgespeeld!'
              : 'Je hebt 8 sterren verdiend! Je mag nu je voortuin én een speelplek inrichten.'}
          </p>
          <Button className="primary" onClick={onClaim}>
            Mijn beloning ophalen →
          </Button>
        </div>
      ) : (
        <div className="mission-intro">
          <span className="mission-large-icon">🏡</span>
          <h2>Dit heb jij voor elkaar gekregen!</h2>
          <p>
            Je tas is gevonden en je hebt geholpen op school. Maak nu jouw buurt
            gezellig.
          </p>
          <div className="mission-actions">
            <Button className="primary" onClick={onBuild}>
              Mijn buurt inrichten →
            </Button>
            <Button
              className="soft"
              onClick={() => {
                onUpdate({ phase: 'intro' });
              }}
            >
              Avontuur opnieuw spelen
            </Button>
            <Button className="soft" onClick={onHome}>
              Terug naar de buurt
            </Button>
          </div>
        </div>
      )}
    </section>
  );
}

'use client';
import { useEffect, useRef, useState } from 'react';
import {
  hairStyles,
  hairColors,
  topStyles,
  bottomStyles,
  jacketStyles,
  shoeStyles,
  type AvatarLook,
} from '@/lib/wardrobe';
import {
  prepareSprite,
  composeAvatar,
  type Sprite,
} from '@/lib/avatar-renderer';
export { hairStyles, hairColors, type AvatarLook } from '@/lib/wardrobe';
const make = () => {
  const c = document.createElement('canvas');
  c.width = c.height = 400;
  return c;
};
let assets:
  | Promise<{ heads: Sprite[]; clothes: Sprite[]; dress: Sprite }>
  | undefined;
const rendered = new Map<string, HTMLCanvasElement>();
function loadAssets() {
  if (!assets)
    assets = Promise.all(
      ['/avatars.png', '/hair-16.png', '/clothes.png'].map(
        (src) =>
          new Promise<HTMLImageElement>((resolve, reject) => {
            const image = new Image();
            image.onload = () => resolve(image);
            image.onerror = () => reject(new Error('Avatar laden mislukt'));
            image.src = src;
          }),
      ),
    )
      .then(([legacy, hair, clothes]) => {
        const originals = Array.from({ length: 4 }, (_, i) =>
          prepareSprite(legacy, i, 'legacy', make),
        );
        return {
          heads: [
            ...originals,
            ...Array.from({ length: 16 }, (_, i) =>
              prepareSprite(hair, i, 'hair', make),
            ),
          ],
          clothes: Array.from({ length: 16 }, (_, i) =>
            prepareSprite(clothes, i, 'clothes', make),
          ),
          dress: originals[0],
        };
      })
      .catch((error) => {
        assets = undefined;
        throw error;
      });
  return assets;
}
const accessoryIcons: Record<string, string> = {
  bow: '🎀',
  flower: '🌸',
  crown: '👑',
  butterfly: '🦋',
};
export function Avatar({
  look,
  compact = false,
}: {
  look: AvatarLook;
  compact?: boolean;
}) {
  const ref = useRef<HTMLCanvasElement>(null),
    [failed, setFailed] = useState(false);
  const key = JSON.stringify([
    look.hairStyle,
    look.hairColor,
    look.color,
    look.outfit,
    look.top,
    look.bottom,
    look.jacket,
    look.shoes,
    look.topColor,
    look.bottomColor,
    look.jacketColor,
    look.shoeColor,
  ]);
  useEffect(() => {
    let active = true;
    loadAssets()
      .then((a) => {
        if (!active) return;
        let sprite = rendered.get(key);
        if (!sprite) {
          sprite = composeAvatar(
            look,
            a.heads[look.hairStyle],
            a.clothes,
            a.dress,
            make,
          );
          if (rendered.size >= 100)
            rendered.delete(rendered.keys().next().value!);
          rendered.set(key, sprite);
        }
        const ctx = ref.current?.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, 400, 400);
          ctx.drawImage(sprite, 0, 0);
        }
        setFailed(false);
      })
      .catch(() => {
        if (active) setFailed(true);
      });
    return () => {
      active = false;
    };
  }, [key]);
  const outfit =
    look.outfit === 'dress'
      ? 'een jurk'
      : `${topStyles[look.top]} en ${bottomStyles[look.bottom]}`;
  return (
    <div className={`custom-avatar ${compact ? 'compact' : ''}`}>
      <canvas
        ref={ref}
        width={400}
        height={400}
        role="img"
        aria-label={`${hairStyles[look.hairStyle]}, ${hairColors[look.hairColor][0]} haar, ${outfit}, ${jacketStyles[look.jacket]}, ${shoeStyles[look.shoes]}`}
      />
      {failed && (
        <span className="avatar-error">
          Poppetje laden lukt niet. Ververs de pagina.
        </span>
      )}
      {look.extra !== 'none' && (
        <span aria-hidden="true" className={`avatar-accessory ${look.extra}`}>
          {accessoryIcons[look.extra]}
        </span>
      )}
    </div>
  );
}

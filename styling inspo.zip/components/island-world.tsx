'use client';
import { useEffect, useRef, useState } from 'react';
import { Decoration } from './neighborhood-builder';
import {
  gardenItems,
  playgroundItems,
  type NeighborhoodSave,
} from '@/lib/neighborhood';
import { Button } from '@/components/ui/button';
import { Avatar, type AvatarLook } from './avatar';
import {
  advance,
  cameraOffset,
  constrainToPath,
  distance,
  nearestPlace,
  PLACES,
  routeTo,
  type Point,
} from '@/lib/world';
export function IslandWorld({
  look,
  neighborhood,
  name,
  position,
  onPosition,
  onEnter,
}: {
  look: AvatarLook;
  neighborhood: NeighborhoodSave;
  name: string;
  position: Point;
  onPosition: (p: Point) => void;
  onEnter: (id: string) => void;
}) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const [viewport, setViewport] = useState({ width: 1000, height: 550 });
  const [overview, setOverview] = useState(false);
  const [p, setP] = useState(constrainToPath(position)),
    [walking, setWalking] = useState(false),
    [facing, setFacing] = useState(1),
    [destination, setDestination] = useState<string | null>(null);
  const current = useRef(constrainToPath(position)),
    keys = useRef(new Set<string>()),
    route = useRef<Point[]>([]),
    callbacks = useRef({ onPosition, onEnter }),
    last = useRef(0);
  callbacks.current = { onPosition, onEnter };
  const nearby = nearestPlace(p);
  const selected = PLACES.find((place) => place.id === destination);
  const region =
    nearby?.region ||
    (p.x >= 40 && p.x <= 60 && p.y >= 38 && p.y <= 65
      ? 'Groene plein'
      : p.y < 50
        ? p.x < 50
          ? 'Onze straat'
          : 'Schoolplein'
        : p.y > 70
          ? p.x < 50
            ? 'Buurttuin'
            : 'Speelveld'
          : 'Groene plein');
  const sceneWidth = overview
    ? Math.min(viewport.width, viewport.height * 1.5)
    : Math.max(viewport.width * 2.4, 1900);
  const scene = { width: sceneWidth, height: (sceneWidth * 2) / 3 };
  const camera = cameraOffset(p, scene, viewport);
  useEffect(() => {
    const element = viewportRef.current;
    if (!element) return;
    const observer = new ResizeObserver(([entry]) =>
      setViewport({
        width: entry.contentRect.width,
        height: entry.contentRect.height,
      }),
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  function go(to: Point, id?: string) {
    keys.current.clear();
    route.current = routeTo(current.current, to);
    setDestination(id || null);
  }
  useEffect(() => {
    let frame: number;
    const movement = [
      'arrowleft',
      'arrowright',
      'arrowup',
      'arrowdown',
      'w',
      'a',
      's',
      'd',
    ];
    function clear() {
      keys.current.clear();
      route.current = [];
      setWalking(false);
    }
    function down(e: KeyboardEvent) {
      if (
        e.target instanceof HTMLElement &&
        e.target.closest('input,textarea,select')
      )
        return;
      const key = e.key.toLowerCase();
      if (movement.includes(key)) {
        e.preventDefault();
        keys.current.add(key);
        route.current = [];
        setDestination(null);
      }
      if (
        (key === 'e' || key === 'enter') &&
        !e.repeat &&
        (!(e.target instanceof HTMLElement && e.target.closest('button,a')) ||
          key === 'e' ||
          (e.target instanceof HTMLElement &&
            Boolean(
              e.target.closest('.destination-button,.village-door,.walk-key'),
            )))
      ) {
        const place = nearestPlace(current.current);
        if (place) {
          e.preventDefault();
          callbacks.current.onEnter(place.id);
        }
      }
    }
    function up(e: KeyboardEvent) {
      keys.current.delete(e.key.toLowerCase());
    }
    function visibility() {
      if (document.hidden) clear();
    }
    function tick(time: number) {
      const dt = Math.min((time - last.current) / 1000, 0.04);
      last.current = time;
      let next = current.current;
      const k = keys.current;
      let dx =
          Number(k.has('arrowright') || k.has('d')) -
          Number(k.has('arrowleft') || k.has('a')),
        dy =
          Number(k.has('arrowdown') || k.has('s')) -
          Number(k.has('arrowup') || k.has('w'));
      if (dx || dy) {
        const l = Math.hypot(dx, dy);
        next = constrainToPath({
          x: next.x + (dx / l) * dt * 8,
          y: next.y + (dy / l) * dt * 12,
        });
      } else if (route.current.length) {
        next = advance(next, route.current[0], dt * 8);
        if (distance(next, route.current[0]) < 0.05) route.current.shift();
      }
      const moving = distance(current.current, next) > 0.002;
      if (moving) {
        if (Math.abs(next.x - current.current.x) > 0.01)
          setFacing(next.x > current.current.x ? 1 : -1);
        current.current = next;
        setP(next);
      }
      setWalking(moving);
      frame = requestAnimationFrame(tick);
    }
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', clear);
    document.addEventListener('visibilitychange', visibility);
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', clear);
      document.removeEventListener('visibilitychange', visibility);
      callbacks.current.onPosition(current.current);
    };
  }, []);
  return (
    <section className="world-section" aria-label="Loop door je buurt">
      <div
        className={`village-viewport ${overview ? 'overview' : ''}`}
        ref={viewportRef}
      >
        <div className="village-hud">
          <div>
            <small>STERRENEILAND</small>
            <strong>{overview ? 'Onze buurt' : region}</strong>
          </div>
          <Button className="soft" onClick={() => setOverview((v) => !v)}>
            {overview ? '👣 Verder wandelen' : '🗺️ Hele buurt'}
          </Button>
        </div>
        <div
          className="village-plane"
          style={{
            width: scene.width,
            height: scene.height,
            transform: `translate(${camera.x}px,${camera.y}px)`,
          }}
          onPointerDown={(e) => {
            if ((e.target as HTMLElement).closest('button')) return;
            const r = e.currentTarget.getBoundingClientRect();
            go({
              x: ((e.clientX - r.left) / r.width) * 100,
              y: ((e.clientY - r.top) / r.height) * 100,
            });
          }}
        >
          <img
            className="village-art"
            src="/neighborhood.png"
            alt="Een Nederlandse woonwijk met bakstenen rijtjeshuizen, een school, een buurthuis en een groen speelveld"
            draggable={false}
          />
          {neighborhood.garden !== 'none' && (
            <div className="placed-decoration garden-decoration">
              <Decoration
                index={
                  gardenItems.find((g) => g.id === neighborhood.garden)!.index
                }
              />
            </div>
          )}
          {neighborhood.playground !== 'none' && (
            <div className="placed-decoration playground-decoration">
              <Decoration
                index={
                  playgroundItems.find((g) => g.id === neighborhood.playground)!
                    .index
                }
              />
            </div>
          )}
          {PLACES.map((place) => (
            <Button
              key={place.id}
              className={`village-door ${nearby?.id === place.id ? 'nearby' : ''}`}
              style={{ left: `${place.x}%`, top: `${place.y + 1.8}%` }}
              onClick={() => go(place, place.id)}
              aria-label={`Loop naar het ${place.house}`}
            >
              <span>{place.icon}</span>
              <span>
                {place.house}
                <small>{place.name}</small>
              </span>
            </Button>
          ))}
          <div
            className={`village-avatar ${walking ? 'walking' : ''}`}
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
          >
            <div className="avatar-name">{name}</div>
            <div
              className="avatar-turn"
              style={{ transform: `scaleX(${facing})` }}
            >
              <Avatar look={look} compact />
            </div>
          </div>
        </div>
        <div className="village-status" aria-live="polite">
          {selected && walking
            ? `👣 Onderweg naar het ${selected.house.toLowerCase()}`
            : 'Tik op een pad of kies een huisje'}
        </div>
      </div>
      <nav className="village-destinations" aria-label="Kies een huisje">
        {PLACES.map((place) => (
          <Button
            key={place.id}
            className={`destination-button ${destination === place.id ? 'chosen' : ''}`}
            onClick={() => {
              go(place, place.id);
              setOverview(false);
            }}
          >
            <span>{place.icon}</span>
            <span>
              {place.house}
              <small>Loop hierheen</small>
            </span>
          </Button>
        ))}
      </nav>
      <div className="world-bottom">
        <div className="world-controls" aria-label="Loopknoppen">
          {[
            ['arrowleft', '←', 'Links'],
            ['arrowup', '↑', 'Omhoog'],
            ['arrowdown', '↓', 'Omlaag'],
            ['arrowright', '→', 'Rechts'],
          ].map(([key, icon, label]) => (
            <Button
              key={key}
              className="walk-key"
              aria-label={label}
              onPointerDown={(e) => {
                e.preventDefault();
                e.currentTarget.setPointerCapture(e.pointerId);
                route.current = [];
                setDestination(null);
                keys.current.add(key);
              }}
              onPointerUp={() => keys.current.delete(key)}
              onPointerCancel={() => keys.current.delete(key)}
              onLostPointerCapture={() => keys.current.delete(key)}
              onClick={(e) => {
                if (e.detail === 0) {
                  const dx =
                      key === 'arrowleft' ? -1 : key === 'arrowright' ? 1 : 0,
                    dy = key === 'arrowup' ? -1 : key === 'arrowdown' ? 1 : 0;
                  const next = constrainToPath({
                    x: current.current.x + dx * 2,
                    y: current.current.y + dy * 3,
                  });
                  current.current = next;
                  setP(next);
                }
              }}
            >
              {icon}
            </Button>
          ))}
        </div>
        <div className="world-action" aria-live="polite">
          {nearby ? (
            <Button className="primary" onClick={() => onEnter(nearby.id)}>
              {nearby.icon}{' '}
              {nearby.id === 'closet'
                ? 'Binnen in het verkleedhuis'
                : `Naar binnen · ${nearby.name}`}{' '}
              <small>↵</small>
            </Button>
          ) : (
            <p>Loop naar de deur van een huisje ✨</p>
          )}
        </div>
        <span className="keyboard-hint">
          Pijltjes / WASD om te lopen
          <br />
          Enter om naar binnen te gaan
        </span>
      </div>
      <details className="quick-travel">
        <summary>Liever meteen ergens heen?</summary>
        <div>
          {PLACES.map((place) => (
            <Button
              key={place.id}
              className="soft"
              onClick={() => onEnter(place.id)}
            >
              {place.icon} {place.name}
            </Button>
          ))}
        </div>
      </details>
    </section>
  );
}

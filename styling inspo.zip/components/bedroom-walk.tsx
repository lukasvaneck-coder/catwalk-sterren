'use client';
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, type AvatarLook } from './avatar';
import {
  clampRoom,
  roomCamera,
  roomDistance,
  roomStep,
  roomSpots,
  roomItems,
  type RoomPoint,
} from '@/lib/room';
export function BedroomWalk({
  look,
  group,
  packing,
  onPack,
  onLeave,
}: {
  look: AvatarLook;
  group: 3 | 5;
  packing: boolean;
  onPack: () => void;
  onLeave: () => void;
}) {
  const [point, setPoint] = useState<RoomPoint>({ x: 53, y: 85 }),
    [moving, setMoving] = useState(false),
    [face, setFace] = useState(1),
    [clue, setClue] = useState(false),
    [found, setFound] = useState(false),
    [packed, setPacked] = useState<string[]>([]),
    [hint, setHint] = useState(
      packing
        ? 'Loop naar de spullen op je lijstje en pak ze op.'
        : 'Loop naar het bureau rechts. Daar ligt een briefje.',
    ),
    [size, setSize] = useState({ width: 390, height: 750 }),
    [stick, setStick] = useState({ x: 0, y: 0 });
  const viewport = useRef<HTMLDivElement>(null),
    position = useRef(point),
    target = useRef<RoomPoint | null>(null),
    keys = useRef(new Set<string>()),
    axis = useRef({ x: 0, y: 0 }),
    action = useRef(() => {});
  const required =
    group === 3
      ? ['book', 'pencil', 'bottle']
      : ['book', 'pencil', 'bottle', 'lunch'];
  const objects = packing
    ? roomItems.filter((i) => !packed.includes(i.id))
    : roomSpots;
  const nearby = objects.find((o) => roomDistance(point, o) < 4.5);
  const allPacked = required.every((id) => packed.includes(id));
  const camera = roomCamera(point, size);
  const { width, height } = camera;
  function interact() {
    if (packing && allPacked) {
      onLeave();
      return;
    }
    if (found && !packing) {
      onPack();
      setHint('Loop naar de spullen op je lijstje. Pak ze één voor één.');
      return;
    }
    if (!nearby) return;
    if (packing) {
      if (!required.includes(nearby.id)) {
        setHint('De voetbal blijft thuis. Zoek de spullen op je lijstje.');
        return;
      }
      setPacked((p) => (p.includes(nearby.id) ? p : [...p, nearby.id]));
      setHint('Die zit in je tas! Zoek het volgende voorwerp.');
    } else if (nearby.id === 'desk') {
      setClue(true);
      setHint('Het briefje zegt: je tas ligt onder het bed!');
    } else if (nearby.id === 'bed') {
      if (clue) {
        setFound(true);
        setHint('Gevonden! Nu je schoolspullen nog.');
      } else
        setHint(
          'Even onder het bed kijken? Lees eerst het briefje op het bureau.',
        );
    } else setHint('Hier zijn je kleren. Loop eens naar het bureau.');
  }
  action.current = interact;
  useEffect(() => {
    const el = viewport.current;
    if (!el) return;
    const observer = new ResizeObserver(([e]) =>
      setSize({ width: e.contentRect.width, height: e.contentRect.height }),
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    let frame: number,
      last = 0;
    const movement = [
      'arrowleft',
      'arrowright',
      'arrowup',
      'arrowdown',
      'w',
      'a',
      's',
      'd',
    ];
    function clear() {
      keys.current.clear();
      axis.current = { x: 0, y: 0 };
      setStick({ x: 0, y: 0 });
      target.current = null;
    }
    function down(e: KeyboardEvent) {
      if (
        e.target instanceof HTMLElement &&
        e.target.closest('input,textarea,select')
      )
        return;
      const k = e.key.toLowerCase();
      if (movement.includes(k)) {
        e.preventDefault();
        keys.current.add(k);
        target.current = null;
      }
      if (k === 'e' && !e.repeat) {
        e.preventDefault();
        action.current();
      }
    }
    function up(e: KeyboardEvent) {
      keys.current.delete(e.key.toLowerCase());
    }
    function tick(t: number) {
      const dt = Math.min((t - last) / 1000, 0.04);
      last = t;
      let next = position.current;
      const k = keys.current;
      const dx =
          axis.current.x +
          Number(k.has('arrowright') || k.has('d')) -
          Number(k.has('arrowleft') || k.has('a')),
        dy =
          axis.current.y +
          Number(k.has('arrowdown') || k.has('s')) -
          Number(k.has('arrowup') || k.has('w'));
      if (dx || dy) {
        const l = Math.max(1, Math.hypot(dx, dy));
        next = clampRoom({
          x: next.x + (dx / l) * dt * 13,
          y: next.y + (dy / l) * dt * 19.5,
        });
      } else if (target.current) {
        next = roomStep(next, target.current, dt * 13);
        if (roomDistance(next, target.current) < 0.05) target.current = null;
      }
      const walk = roomDistance(next, position.current) > 0.001;
      if (walk) {
        if (Math.abs(next.x - position.current.x) > 0.001)
          setFace(next.x > position.current.x ? 1 : -1);
        position.current = next;
        setPoint(next);
      }
      setMoving(walk);
      frame = requestAnimationFrame(tick);
    }
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', clear);
    document.addEventListener('visibilitychange', clear);
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', clear);
      document.removeEventListener('visibilitychange', clear);
    };
  }, []);
  function joystick(e: React.PointerEvent<HTMLButtonElement>) {
    const r = e.currentTarget.getBoundingClientRect(),
      dx = (e.clientX - r.left - r.width / 2) / 36,
      dy = (e.clientY - r.top - r.height / 2) / 36,
      l = Math.max(1, Math.hypot(dx, dy));
    axis.current = { x: dx / l, y: dy / l };
    setStick({ x: (dx / l) * 27, y: (dy / l) * 27 });
    target.current = null;
  }
  const label =
    packing && allPacked
      ? 'Naar school →'
      : found && !packing
        ? 'Spullen zoeken →'
        : nearby?.label || 'Loop naar een voorwerp';
  const dialogue = allPacked ? 'Alles zit in je tas. Op naar school!' : hint;
  function narrate() {
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(dialogue);
    utterance.lang = 'nl-NL';
    utterance.rate = 0.9;
    speechSynthesis.speak(utterance);
  }
  useEffect(() => {
    if (!('speechSynthesis' in window)) return;
    let disposed = false;
    const detach = () => {
      window.removeEventListener('pointerdown', retry);
      window.removeEventListener('keydown', retry);
    };
    function retry() {
      if (disposed || document.hidden) return;
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(dialogue);
      utterance.lang = 'nl-NL';
      utterance.rate = 0.9;
      utterance.onstart = detach;
      speechSynthesis.speak(utterance);
    }
    // Mobile browsers can require a gesture before the first spoken line.
    window.addEventListener('pointerdown', retry);
    window.addEventListener('keydown', retry);
    retry();
    return () => {
      disposed = true;
      detach();
      speechSynthesis.cancel();
    };
  }, [dialogue]);
  return (
    <div className="room-game" ref={viewport}>
      <div
        className="room-plane"
        style={{
          width,
          height,
          transform: `translate(${camera.x}px,${camera.y}px)`,
        }}
        onPointerDown={(e) => {
          if ((e.target as HTMLElement).closest('button')) return;
          const r = e.currentTarget.getBoundingClientRect();
          target.current = clampRoom({
            x: ((e.clientX - r.left) / r.width) * 100,
            y: ((e.clientY - r.top) / r.height) * 100,
          });
        }}
      >
        <img
          src="/bedroom.png"
          alt="Je slaapkamer: het bed links, de kast achterin en het bureau rechts"
          draggable={false}
        />
        {objects.map((o) => (
          <Button
            key={o.id}
            className={`room-object ${nearby?.id === o.id ? 'in-reach' : ''}`}
            style={{ left: `${o.x}%`, top: `${o.y}%` }}
            onClick={() => {
              target.current = clampRoom(o);
            }}
            aria-label={`Loop hierheen: ${o.label}`}
          >
            {!packing && o.id === 'bed' && !found ? '🔎' : o.icon}
          </Button>
        ))}
        <div
          className={`room-avatar ${moving ? 'is-walking' : ''}`}
          style={{
            left: `${point.x}%`,
            top: `${point.y}%`,
            width: `${11 + (point.y - 51) * 0.055}%`,
          }}
        >
          <div style={{ transform: `scaleX(${face})` }}>
            <Avatar look={look} compact />
          </div>
        </div>
      </div>
      <div className="room-task">
        <strong>
          {packing ? '🎒 Pak je schooltas' : '🔎 Zoek de schooltas'}
        </strong>
        {packing && (
          <div className="room-list">
            {required.map((id) => (
              <span key={id} className={packed.includes(id) ? 'collected' : ''}>
                {roomItems.find((i) => i.id === id)?.icon}
                {packed.includes(id) ? '✓' : ''}
              </span>
            ))}
          </div>
        )}
      </div>
      <div className="room-dialogue" role="status">
        <span>{dialogue}</span>
        <Button
          className="soft"
          onClick={narrate}
          aria-label="Lees de aanwijzing voor"
        >
          🔊
        </Button>
      </div>
      <div className="room-inputs">
        <Button
          className="room-stick"
          aria-label="Loopstick: sleep om te lopen. Met toetsenbord: pijltjes of WASD."
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            joystick(e);
          }}
          onPointerMove={(e) => {
            if (e.currentTarget.hasPointerCapture(e.pointerId)) joystick(e);
          }}
          onPointerUp={() => {
            axis.current = { x: 0, y: 0 };
            setStick({ x: 0, y: 0 });
          }}
          onPointerCancel={() => {
            axis.current = { x: 0, y: 0 };
            setStick({ x: 0, y: 0 });
          }}
          onLostPointerCapture={() => {
            axis.current = { x: 0, y: 0 };
            setStick({ x: 0, y: 0 });
          }}
        >
          <span style={{ transform: `translate(${stick.x}px,${stick.y}px)` }}>
            ✥
          </span>
        </Button>
        <Button
          className="primary room-action"
          disabled={!nearby && !(found && !packing) && !allPacked}
          onClick={interact}
        >
          {label}
        </Button>
      </div>
    </div>
  );
}

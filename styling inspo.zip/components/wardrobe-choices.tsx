'use client';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Avatar } from './avatar';
import {
  hairStyles,
  hairColors,
  clothingColors,
  topStyles,
  bottomStyles,
  jacketStyles,
  shoeStyles,
  type AvatarLook,
} from '@/lib/wardrobe';
export function WardrobeChoices({
  look,
  onChange,
}: {
  look: AvatarLook;
  onChange: (patch: Partial<AvatarLook>) => void;
}) {
  function swatches(
    field:
      | 'hairColor'
      | 'color'
      | 'topColor'
      | 'bottomColor'
      | 'jacketColor'
      | 'shoeColor',
    label: string,
  ) {
    const palette = field === 'hairColor' ? hairColors : clothingColors;
    return (
      <>
        <h3>{label}</h3>
        <div className="swatches">
          {palette.map(([name, color], i) => (
            <Button
              key={name}
              className={`swatch ${look[field] === i ? 'selected' : ''}`}
              aria-label={`${label}: ${name}`}
              aria-pressed={look[field] === i}
              style={{ background: color }}
              onClick={() => onChange({ [field]: i })}
            >
              {look[field] === i ? '✓' : ''}
            </Button>
          ))}
        </div>
        <p className="hint left">{palette[look[field]][0]}</p>
      </>
    );
  }
  function choices(
    field: 'top' | 'bottom' | 'jacket' | 'shoes',
    names: string[],
    mode?: 'separates',
  ) {
    return (
      <div className="clothing-grid">
        {names.map((name, i) => {
          const preview = {
            ...look,
            [field]: i,
            ...(mode ? { outfit: mode } : {}),
            ...(field === 'top' ? { jacket: 0 } : {}),
            extra: 'none',
          };
          return (
            <Button
              key={name}
              className={`clothing-choice ${look[field] === i && (!mode || look.outfit === mode) ? 'selected' : ''}`}
              aria-pressed={
                look[field] === i && (!mode || look.outfit === mode)
              }
              onClick={() =>
                onChange({ [field]: i, ...(mode ? { outfit: mode } : {}) })
              }
            >
              <Avatar compact look={preview} />
              <span>{name}</span>
            </Button>
          );
        })}
      </div>
    );
  }
  return (
    <Tabs defaultValue="hair" className="wardrobe-tabs">
      <TabsList className="closet-tab-list">
        {[
          ['hair', '💇 Haar'],
          ['dress', '👗 Jurk'],
          ['tops', '👕 Shirts'],
          ['bottoms', '👖 Broek & rok'],
          ['jackets', '🧥 Jasjes'],
          ['shoes', '👟 Schoenen'],
        ].map(([value, label]) => (
          <TabsTrigger value={value} key={value}>
            {label}
          </TabsTrigger>
        ))}
      </TabsList>
      <TabsContent value="hair">
        <h3>20 kapsels om te proberen</h3>
        <div className="hairstyles expanded">
          {hairStyles.map((style, i) => (
            <Button
              key={style}
              className={`hair-choice ${look.hairStyle === i ? 'selected' : ''}`}
              aria-pressed={look.hairStyle === i}
              onClick={() => onChange({ hairStyle: i })}
            >
              <Avatar compact look={{ ...look, hairStyle: i, extra: 'none' }} />
              <span>{style}</span>
            </Button>
          ))}
        </div>
        {swatches('hairColor', 'Welke haarkleur?')}
      </TabsContent>
      <TabsContent value="dress">
        <h3>Je feestjurkje</h3>
        <Button
          className={`primary ${look.outfit === 'dress' ? 'selected' : ''}`}
          aria-pressed={look.outfit === 'dress'}
          onClick={() => onChange({ outfit: 'dress' })}
        >
          👗 Mijn jurkje dragen
        </Button>
        {swatches('color', 'Een kleur voor je jurk')}
        <p className="hint left">Ook leuk met een jasje en andere schoenen!</p>
      </TabsContent>
      <TabsContent value="tops">
        <h3>Kies je shirt</h3>
        {choices('top', topStyles, 'separates')}
        {swatches('topColor', 'Kleur van je shirt')}
      </TabsContent>
      <TabsContent value="bottoms">
        <h3>Een broek of een rokje?</h3>
        {choices('bottom', bottomStyles, 'separates')}
        {swatches('bottomColor', 'Kleur van je broek of rok')}
      </TabsContent>
      <TabsContent value="jackets">
        <h3>Een laagje erbij</h3>
        {choices('jacket', jacketStyles)}
        {swatches('jacketColor', 'Kleur van je jasje')}
      </TabsContent>
      <TabsContent value="shoes">
        <h3>Klaar om op pad te gaan</h3>
        {choices('shoes', shoeStyles)}
        {swatches('shoeColor', 'Kleur van je schoenen')}
      </TabsContent>
      <p className="wardrobe-free">✦ Alle kapsels en kleding zijn van jou.</p>
    </Tabs>
  );
}

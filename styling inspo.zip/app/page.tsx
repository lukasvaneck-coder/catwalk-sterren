'use client';
import { useEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { Button } from '@/components/ui/button';
import { Avatar } from '@/components/avatar';
import { WardrobeChoices } from '@/components/wardrobe-choices';
import { lookDefaults, normalizeLook, type AvatarLook } from '@/lib/wardrobe';
import { IslandWorld } from '@/components/island-world';
import { PLACES, type Point } from '@/lib/world';
import { SchoolAdventure } from '@/components/school-adventure';
import { NeighborhoodBuilder } from '@/components/neighborhood-builder';
import {
  defaultNeighborhood,
  normalizeNeighborhood,
  claimNeighborhoodReward,
  missionLabels,
  type NeighborhoodSave,
} from '@/lib/neighborhood';
const games = [
  {
    id: 'catch',
    icon: '⭐',
    title: 'Sterren vangen',
    desc: 'Tik de fonkelende sterren aan.',
    help: 'Tik op de ster voordat hij verdwijnt. Met een toetsenbord: gebruik de cijfers 1 tot en met 9.',
  },
  {
    id: 'memory',
    icon: '🦋',
    title: 'Vlinder-memory',
    desc: 'Welke plaatjes horen bij elkaar?',
    help: 'Draai twee kaartjes om. Zoek alle dezelfde plaatjes. Neem zoveel tijd als je wilt.',
  },
  {
    id: 'dance',
    icon: '🎵',
    title: 'Dansfeest',
    desc: 'Onthoud de pasjes en dans mee.',
    help: 'Kijk welke pijlen oplichten. Tik daarna dezelfde pijlen in dezelfde volgorde. Je mag ook de pijltjestoetsen gebruiken.',
  },
];
const extras = [
  { id: 'none', icon: '✦', name: 'Zonder', cost: 0 },
  { id: 'bow', icon: '🎀', name: 'Strik', cost: 0 },
  { id: 'flower', icon: '🌸', name: 'Bloem', cost: 8 },
  { id: 'crown', icon: '👑', name: 'Kroontje', cost: 15 },
  { id: 'butterfly', icon: '🦋', name: 'Vlinder', cost: 12 },
];
type Save = AvatarLook & {
  name: string;
  stars: number;
  unlocked: string[];
  hard: boolean;
  neighborhood: NeighborhoodSave;
};
const initial: Save = {
  ...lookDefaults,
  name: 'Sterretje',
  stars: 0,
  unlocked: ['none', 'bow'],
  hard: false,
  neighborhood: defaultNeighborhood,
};
function readSave(raw: string | null): Save {
  try {
    const s = JSON.parse(raw || 'null');
    if (!s || typeof s !== 'object') return initial;
    const unlocked = [
      ...new Set([
        'none',
        'bow',
        ...extras
          .filter((e) => Array.isArray(s.unlocked) && s.unlocked.includes(e.id))
          .map((e) => e.id),
      ]),
    ];
    const look = normalizeLook(s);
    return {
      ...look,
      name: typeof s.name === 'string' ? s.name.slice(0, 20) : initial.name,
      stars: Number.isSafeInteger(s.stars) && s.stars >= 0 ? s.stars : 0,
      unlocked,
      hard: s.hard === true,
      neighborhood: normalizeNeighborhood(s.neighborhood),
      extra: unlocked.includes(look.extra) ? look.extra : 'bow',
    };
  } catch {
    return initial;
  }
}
function say(text: string) {
  if ('speechSynthesis' in window) {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'nl-NL';
    u.rate = 0.88;
    speechSynthesis.speak(u);
  }
}
function CatchGame({
  hard,
  finish,
}: {
  hard: boolean;
  finish: (score: number) => void;
}) {
  const [round, setRound] = useState(0),
    [target, setTarget] = useState(() => Math.floor(Math.random() * 9)),
    [caught, setCaught] = useState(false),
    [score, setScore] = useState(0);
  const scoreRef = useRef(0),
    taken = useRef(false);
  useEffect(() => {
    const timer = setInterval(
      () => {
        setRound((r) => r + 1);
        setTarget((t) => {
          const next = Math.floor(Math.random() * 8);
          return next >= t ? next + 1 : next;
        });
        taken.current = false;
        setCaught(false);
      },
      hard ? 850 : 1700,
    );
    return () => clearInterval(timer);
  }, [hard]);
  useEffect(() => {
    if (round >= 15) finish(Math.max(3, Math.ceil(scoreRef.current / 2)));
  }, [round, finish]);
  function tap(i: number) {
    if (i !== target || taken.current || round >= 15) return;
    taken.current = true;
    scoreRef.current++;
    setScore(scoreRef.current);
    setCaught(true);
  }
  useEffect(() => {
    function key(e: KeyboardEvent) {
      const i = Number(e.key) - 1;
      if (i >= 0 && i < 9) {
        e.preventDefault();
        tap(i);
      }
    }
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  });
  return (
    <>
      <div className="game-status">
        <span>⭐ {score} gevangen</span>
        <span>{Math.min(round + 1, 15)} / 15</span>
      </div>
      <div className="catch-board">
        {Array.from({ length: 9 }, (_, i) => (
          <Button
            className={`catch-cell ${i === target && !caught ? 'lit' : ''}`}
            key={i}
            aria-label={`Vak ${i + 1}${i === target && !caught ? ', ster' : ''}`}
            onClick={() => tap(i)}
          >
            <small>{i + 1}</small>
            {i === target ? (caught ? '✨' : '⭐') : '·'}
          </Button>
        ))}
      </div>
      <p className="hint">
        Tik op de ster!{' '}
        {hard ? 'Hij is lekker snel.' : 'Je hebt rustig de tijd.'}
      </p>
    </>
  );
}
function MemoryGame({
  hard,
  finish,
}: {
  hard: boolean;
  finish: (score: number) => void;
}) {
  const [cards] = useState(() => {
      const icons = ['🦋', '🌸', '🍓', '🌈', '🐬', '🍒'].slice(0, hard ? 6 : 4);
      const a = [...icons, ...icons];
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    }),
    [open, setOpen] = useState<number[]>([]),
    [matched, setMatched] = useState<number[]>([]),
    [moves, setMoves] = useState(0);
  useEffect(() => {
    if (open.length !== 2) return;
    const [a, b] = open;
    const timer = setTimeout(
      () => {
        if (cards[a] === cards[b]) setMatched((m) => [...m, a, b]);
        setOpen([]);
      },
      cards[a] === cards[b] ? 450 : 1000,
    );
    return () => clearTimeout(timer);
  }, [open, cards]);
  useEffect(() => {
    if (matched.length === cards.length) finish(hard ? 10 : 7);
  }, [matched, cards, hard, finish]);
  return (
    <>
      <div className="game-status">
        <span>
          🦋 {matched.length / 2} / {cards.length / 2} paartjes
        </span>
        <span>{moves} beurten · geen haast</span>
      </div>
      <div className="memory-board">
        {cards.map((c, i) => (
          <Button
            key={i}
            className={`memory-card ${matched.includes(i) ? 'matched' : ''}`}
            disabled={
              open.includes(i) || matched.includes(i) || open.length === 2
            }
            aria-label={
              open.includes(i) || matched.includes(i)
                ? c
                : `Kaart ${i + 1}, omdraaien`
            }
            onClick={() => {
              setOpen((o) => [...o, i]);
              if (open.length === 1) setMoves((m) => m + 1);
            }}
          >
            {open.includes(i) || matched.includes(i) ? c : '✦'}
          </Button>
        ))}
      </div>
      <p className="hint">Twee dezelfde? Die mogen blijven liggen!</p>
    </>
  );
}
const arrows = ['←', '↑', '↓', '→'],
  keys = ['ArrowLeft', 'ArrowUp', 'ArrowDown', 'ArrowRight'];
function DanceGame({
  hard,
  finish,
}: {
  hard: boolean;
  finish: (score: number) => void;
}) {
  const [sequence, setSequence] = useState(() =>
      Array.from({ length: hard ? 4 : 2 }, () => Math.floor(Math.random() * 4)),
    ),
    [round, setRound] = useState(1),
    [phase, setPhase] = useState<'show' | 'play' | 'next'>('show'),
    [lit, setLit] = useState(-1),
    [index, setIndex] = useState(0),
    [replay, setReplay] = useState(0),
    [message, setMessage] = useState('Kijk goed naar de pasjes!');
  const gate = useRef(false);
  useEffect(() => {
    if (phase !== 'show') return;
    setMessage('Kijk goed naar de pasjes!');
    const timers: ReturnType<typeof setTimeout>[] = [];
    sequence.forEach((v, i) => {
      timers.push(setTimeout(() => setLit(v), 500 + i * 850));
      timers.push(setTimeout(() => setLit(-1), 1050 + i * 850));
    });
    timers.push(
      setTimeout(
        () => {
          gate.current = false;
          setPhase('play');
          setMessage('Nu jij!');
          setIndex(0);
        },
        500 + sequence.length * 850,
      ),
    );
    return () => timers.forEach(clearTimeout);
  }, [sequence, phase, replay]);
  useEffect(() => {
    if (phase !== 'next') return;
    const t = setTimeout(() => {
      if (round === 3) {
        finish(hard ? 10 : 7);
        return;
      }
      setRound((r) => r + 1);
      setSequence((s) => [...s, Math.floor(Math.random() * 4)]);
      setPhase('show');
    }, 850);
    return () => clearTimeout(t);
  }, [phase, round, finish]);
  function tap(i: number) {
    if (phase !== 'play' || gate.current) return;
    if (sequence[index] !== i) {
      gate.current = true;
      setLit(-1);
      setIndex(0);
      setPhase('show');
      setReplay((r) => r + 1);
      return;
    }
    if (index + 1 === sequence.length) {
      gate.current = true;
      setPhase('next');
      setMessage('Ja! Dat was jouw dansje! ✨');
    } else {
      setIndex((n) => n + 1);
      setMessage('Goed zo! En dan…');
    }
  }
  useEffect(() => {
    function key(e: KeyboardEvent) {
      const i = keys.indexOf(e.key);
      if (i >= 0) {
        e.preventDefault();
        if (!e.repeat) tap(i);
      }
    }
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  });
  return (
    <>
      <div className="game-status">
        <span>🎵 Dansje {round} / 3</span>
        <span>
          {phase === 'play'
            ? `${index} / ${sequence.length} pasjes`
            : 'Even kijken…'}
        </span>
      </div>
      <div className="dance-message" aria-live="polite">
        {message}
      </div>
      <div className="dance-board">
        {arrows.map((a, i) => (
          <Button
            key={a}
            className={`dance-pad pad-${i} ${lit === i ? 'lit' : ''}`}
            disabled={phase !== 'play'}
            aria-label={['Links', 'Omhoog', 'Omlaag', 'Rechts'][i]}
            onClick={() => tap(i)}
          >
            {a}
          </Button>
        ))}
      </div>
      <Button
        className="soft"
        disabled={phase !== 'play'}
        onClick={() => {
          setPhase('show');
          setReplay((r) => r + 1);
        }}
      >
        👀 Nog eens kijken
      </Button>
    </>
  );
}
export default function Home() {
  const [save, setSave] = useState<Save>(initial),
    [ready, setReady] = useState(false),
    [storageOK, setStorageOK] = useState(true),
    [screen, setScreen] = useState('island'),
    [started, setStarted] = useState(false),
    [reward, setReward] = useState<number | null>(null),
    [attempt, setAttempt] = useState(0),
    [notice, setNotice] = useState('');
  const awarded = useRef(false);
  const [worldPosition, setWorldPosition] = useState<Point>({ x: 50, y: 49 });
  useEffect(() => {
    try {
      const stored = localStorage.getItem('sterreneiland-v1');
      setSave(readSave(stored));
      if (!stored) setScreen('closet');
    } catch {
      setStorageOK(false);
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem('sterreneiland-v1', JSON.stringify(save));
    } catch {
      setStorageOK(false);
    }
  }, [save, ready]);
  function navigate(next: string) {
    speechSynthesisSafeCancel();
    setScreen(next);
    setStarted(false);
    setReward(null);
    awarded.current = false;
    setNotice('');
  }
  useEffect(() => {
    type MC = {
      registerTool: (
        tool: {
          name: string;
          description: string;
          inputSchema: object;
          execute: (input: unknown) => unknown;
          annotations: object;
        },
        options: { signal: AbortSignal },
      ) => void | Promise<void>;
    };
    const ctx = (document as Document & { modelContext?: MC }).modelContext;
    if (!ctx) return;
    const lifecycle = new AbortController();
    try {
      Promise.resolve(
        ctx.registerTool(
          {
            name: 'open_sterreneiland_activity',
            description:
              'Open de verkleedkamer of de uitleg voor een minigame.',
            inputSchema: {
              type: 'object',
              properties: {
                activity: {
                  type: 'string',
                  enum: [
                    'island',
                    'closet',
                    'catch',
                    'memory',
                    'dance',
                    'adventure',
                    'build',
                    'school',
                    'club',
                    'playground',
                  ],
                },
              },
              required: ['activity'],
              additionalProperties: false,
            },
            annotations: { readOnlyHint: false },
            execute: (input) => {
              const a = (input as { activity?: unknown })?.activity;
              if (
                typeof a !== 'string' ||
                ![
                  'island',
                  'closet',
                  'catch',
                  'memory',
                  'dance',
                  'adventure',
                  'build',
                  'school',
                  'club',
                  'playground',
                ].includes(a)
              )
                throw new Error('Onbekend spel');
              flushSync(() => navigate(a));
              return { activity: a, started: false };
            },
          },
          { signal: lifecycle.signal },
        ),
      ).catch(() => {});
    } catch {}
    return () => lifecycle.abort();
  }, []);
  function updateNeighborhood(patch: Partial<NeighborhoodSave>) {
    setSave((s) => ({ ...s, neighborhood: { ...s.neighborhood, ...patch } }));
  }
  function finish(points: number) {
    if (awarded.current) return;
    awarded.current = true;
    setReward(points);
    setSave((s) => ({ ...s, stars: s.stars + points }));
  }
  function start() {
    awarded.current = false;
    setReward(null);
    setAttempt((n) => n + 1);
    setStarted(true);
  }
  function accessory(id: string) {
    const e = extras.find((x) => x.id === id)!;
    if (save.unlocked.includes(id)) {
      setSave((s) => ({ ...s, extra: id }));
      setNotice('');
      return;
    }
    if (save.stars < e.cost) {
      setNotice(
        `Nog ${e.cost - save.stars} sterren voor ${e.name.toLowerCase()}. Speel een spelletje!`,
      );
      return;
    }
    setSave((s) => ({
      ...s,
      stars: s.stars - e.cost,
      extra: id,
      unlocked: [...s.unlocked, id],
    }));
    setNotice(`${e.icon} ${e.name} is nu van jou!`);
  }
  const game = games.find((g) => g.id === screen);
  return (
    <main className={`game-shell screen-${screen}`}>
      <header>
        <a
          className="logo"
          href="/"
          onClick={(e) => {
            e.preventDefault();
            navigate('island');
          }}
        >
          ✦{' '}
          <span>
            Sterreneiland<small>MIJN BUURTAVONTUREN</small>
          </span>
        </a>
        <div className="wallet" aria-live="polite">
          ⭐ {save.stars} sterren
        </div>
      </header>
      {screen === 'island' ? (
        <>
          <section className="welcome">
            <div>
              <p className="eyebrow">HALLO, {save.name.toUpperCase()}!</p>
              <h1>
                Welkom in jouw buurt.
                <span>Van je eigen huis naar een nieuw avontuur.</span>
              </h1>
            </div>
            <Button className="soft" onClick={() => navigate('closet')}>
              👗 Mijn avatar
            </Button>
          </section>
          <div className="mission-banner">
            <div>
              <small>JOUW AVONTUUR</small>
              <strong>🎒 {missionLabels[save.neighborhood.phase]}</strong>
            </div>
            <div className="mission-actions">
              <Button
                className="primary"
                disabled={!ready}
                onClick={() => navigate('adventure')}
              >
                {save.neighborhood.phase === 'intro'
                  ? 'Start avontuur'
                  : 'Verder spelen'}{' '}
                →
              </Button>
              <Button className="soft" onClick={() => navigate('build')}>
                🌱 Mijn buurt
              </Button>
            </div>
          </div>
          <IslandWorld
            neighborhood={save.neighborhood}
            look={save}
            name={save.name}
            position={worldPosition}
            onPosition={setWorldPosition}
            onEnter={navigate}
          />
        </>
      ) : (
        <>
          <nav className="backbar">
            <Button className="soft" onClick={() => navigate('island')}>
              ← Naar de buurt
            </Button>
            <span>
              {screen === 'closet'
                ? '👗 Mijn avatar'
                : screen === 'adventure'
                  ? '🎒 De verdwenen schooltas'
                  : screen === 'build'
                    ? '🌱 Mijn buurt'
                    : PLACES.find((p) => p.id === screen)?.house ||
                      `${game?.icon} ${game?.title}`}
            </span>
          </nav>
          {screen === 'adventure' ? (
            <SchoolAdventure
              look={save}
              mission={save.neighborhood}
              onUpdate={updateNeighborhood}
              onClaim={() => setSave((s) => claimNeighborhoodReward(s))}
              onBuild={() => navigate('build')}
              onHome={() => navigate('island')}
            />
          ) : screen === 'build' ? (
            <NeighborhoodBuilder
              mission={save.neighborhood}
              onUpdate={updateNeighborhood}
              onMission={() => navigate('adventure')}
              onHome={() => navigate('island')}
            />
          ) : ['school', 'club', 'playground'].includes(screen) ? (
            <section className="adventure-panel">
              <p className="eyebrow">KOM BINNEN</p>
              <h1>{PLACES.find((p) => p.id === screen)?.house}</h1>
              <p>
                {screen === 'school'
                  ? 'Een tas vol spullen, een kaartje maken en fruit verdelen. Wat ga jij vandaag doen?'
                  : screen === 'club'
                    ? 'Een gezellige plek om samen spelletjes te spelen.'
                    : 'Tijd om te bewegen! Speel een spelletje of richt het grasveld in.'}
              </p>
              <div className="hub-activities">
                {screen === 'school' ? (
                  <Button
                    className="primary"
                    onClick={() => navigate('adventure')}
                  >
                    🎒 Mijn schoolavontuur →
                  </Button>
                ) : (
                  games
                    .filter((g) =>
                      screen === 'club' ? g.id === 'memory' : g.id !== 'memory',
                    )
                    .map((g) => (
                      <Button
                        className="soft"
                        key={g.id}
                        onClick={() => navigate(g.id)}
                      >
                        {g.icon} {g.title} →
                      </Button>
                    ))
                )}
                <Button className="soft" onClick={() => navigate('build')}>
                  🌱 De buurt inrichten
                </Button>
              </div>
            </section>
          ) : screen === 'closet' ? (
            <section className="wardrobe">
              <div className="doll-panel">
                <div className="name-tag">✦ {save.name}</div>
                <Avatar look={save} />
                <p>Helemaal jouw stijl!</p>
              </div>
              <div className="wardrobe-options">
                <p className="eyebrow">MIX, MATCH & STRAAL</p>
                <h1>Maak jouw poppetje</h1>
                <label className="name-label">
                  Mijn speelnaam
                  <input
                    value={save.name}
                    maxLength={20}
                    onChange={(e) =>
                      setSave((s) => ({ ...s, name: e.target.value }))
                    }
                    onBlur={() => {
                      if (!save.name.trim())
                        setSave((s) => ({ ...s, name: 'Sterretje' }));
                    }}
                  />
                </label>
                <WardrobeChoices
                  look={save}
                  onChange={(patch) => setSave((s) => ({ ...s, ...patch }))}
                />
                <h3>En iets leuks erbij</h3>
                <div className="extras">
                  {extras.map((e) => (
                    <Button
                      key={e.id}
                      className={`extra ${save.extra === e.id ? 'selected' : ''}`}
                      aria-pressed={save.extra === e.id}
                      onClick={() => accessory(e.id)}
                    >
                      <span>{e.icon}</span>
                      <strong>{e.name}</strong>
                      <small>
                        {save.unlocked.includes(e.id)
                          ? 'Van jou'
                          : `⭐ ${e.cost}`}
                      </small>
                    </Button>
                  ))}
                </div>
                <p className="notice" role="status">
                  {notice ||
                    'Verdien sterren met de spelletjes voor nieuwe accessoires.'}
                </p>
                <Button className="primary" onClick={() => navigate('island')}>
                  Klaar! Tijd om te wandelen ✦
                </Button>
              </div>
            </section>
          ) : (
            game && (
              <section className={`play-panel house-interior house-${screen}`}>
                <p className="house-label">
                  {screen === 'memory' ? '🏠 Buurthuis' : '⚽ Sporthuis'}
                </p>
                <div className="play-heading">
                  <h1>{game.title}</h1>
                  <Button className="soft" onClick={() => say(game.help)}>
                    🔊 Uitleg
                  </Button>
                </div>
                {reward !== null ? (
                  <div className="result" role="status">
                    <span className="result-star">🌟</span>
                    <h2>Wat goed gedaan!</h2>
                    <p>
                      Je hebt <strong>{reward} sterren</strong> verdiend.
                    </p>
                    <div className="result-actions">
                      <Button className="primary" onClick={start}>
                        Nog een keer ↻
                      </Button>
                      <Button
                        className="soft"
                        onClick={() => navigate('closet')}
                      >
                        👗 Naar de verkleedkamer
                      </Button>
                    </div>
                  </div>
                ) : !started ? (
                  <div className="intro">
                    <span className="intro-icon">{game.icon}</span>
                    <p>{game.help}</p>
                    <fieldset>
                      <legend>Hoe wil je spelen?</legend>
                      <Button
                        className={`soft ${!save.hard ? 'selected' : ''}`}
                        aria-pressed={!save.hard}
                        onClick={() => setSave((s) => ({ ...s, hard: false }))}
                      >
                        🌼 Lekker rustig
                      </Button>
                      <Button
                        className={`soft ${save.hard ? 'selected' : ''}`}
                        aria-pressed={save.hard}
                        onClick={() => setSave((s) => ({ ...s, hard: true }))}
                      >
                        🚀 Extra uitdaging
                      </Button>
                    </fieldset>
                    <Button
                      className="primary start"
                      disabled={!ready}
                      onClick={start}
                    >
                      Spelen! ▶
                    </Button>
                  </div>
                ) : (
                  <div key={attempt}>
                    {screen === 'catch' ? (
                      <CatchGame hard={save.hard} finish={finish} />
                    ) : screen === 'memory' ? (
                      <MemoryGame hard={save.hard} finish={finish} />
                    ) : (
                      <DanceGame hard={save.hard} finish={finish} />
                    )}
                  </div>
                )}
              </section>
            )
          )}
        </>
      )}
      <footer className={storageOK ? 'storage-ok' : 'storage-warning'}>
        {storageOK
          ? 'Jouw outfits en sterren blijven op dit apparaat bewaard.'
          : 'Bewaren lukt hier niet. Je kunt spelen, maar je voortgang verdwijnt bij afsluiten.'}{' '}
        <span>✦</span>
      </footer>
    </main>
  );
}
function speechSynthesisSafeCancel() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window)
    speechSynthesis.cancel();
}

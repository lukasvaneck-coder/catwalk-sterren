export type Point = { x: number; y: number };
// Sidewalk centers and front doors in neighborhood.png.
export const PATH: Point[] = [
  { x: 32.5, y: 26 },
  { x: 35.5, y: 32 },
  { x: 54.5, y: 23 },
  { x: 68.8, y: 40 },
  { x: 81.8, y: 32 },
  { x: 49, y: 51 },
  { x: 22.8, y: 61 },
  { x: 14, y: 41 },
  { x: 61.5, y: 71.5 },
  { x: 41, y: 81 },
  { x: 82.5, y: 60 },
  { x: 84.5, y: 73 },
  { x: 25, y: 83 },
  { x: 32, y: 88 },
  { x: 37, y: 94 },
  { x: 77, y: 65 },
  { x: 81, y: 75 },
];
export const EDGES: [number, number][] = [
  [0, 1],
  [1, 2],
  [2, 3],
  [3, 4],
  [1, 5],
  [5, 3],
  [5, 6],
  [6, 7],
  [7, 1],
  [5, 8],
  [8, 9],
  [9, 6],
  [8, 10],
  [10, 3],
  [10, 15],
  [15, 16],
  [16, 11],
  [6, 9],
  [9, 13],
  [13, 12],
  [13, 14],
];
export const PATH_RADIUS = 1.5;
export const distance = (a: Point, b: Point) =>
  Math.hypot(a.x - b.x, ((a.y - b.y) * 2) / 3);
export function projectToPath(p: Point) {
  let best = { point: PATH[0], segment: 0, t: 0, distance: Infinity };
  for (let i = 0; i < EDGES.length; i++) {
    const a = PATH[EDGES[i][0]],
      b = PATH[EDGES[i][1]],
      dx = b.x - a.x,
      dy = ((b.y - a.y) * 2) / 3;
    const t = Math.max(
      0,
      Math.min(
        1,
        ((p.x - a.x) * dx + (((p.y - a.y) * 2) / 3) * dy) / (dx * dx + dy * dy),
      ),
    );
    const point = { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
    const d = distance(p, point);
    if (d < best.distance) best = { point, segment: i, t, distance: d };
  }
  return best;
}
export function constrainToPath(p: Point): Point {
  const closest = projectToPath(p);
  if (closest.distance <= PATH_RADIUS) return p;
  const ratio = PATH_RADIUS / closest.distance;
  return {
    x: closest.point.x + (p.x - closest.point.x) * ratio,
    y: closest.point.y + (p.y - closest.point.y) * ratio,
  };
}
// Add the exact start and goal projections to the path graph, then use Dijkstra.
export function routeTo(from: Point, to: Point): Point[] {
  const a = projectToPath(from),
    b = projectToPath(to);
  const points = [...PATH, a.point, b.point],
    start = PATH.length,
    goal = start + 1;
  const links: [number, number][] = [
    ...EDGES,
    [start, EDGES[a.segment][0]],
    [start, EDGES[a.segment][1]],
    [goal, EDGES[b.segment][0]],
    [goal, EDGES[b.segment][1]],
  ];
  if (a.segment === b.segment) links.push([start, goal]);
  const cost = points.map(() => Infinity),
    prev = points.map(() => -1),
    visited = new Set<number>();
  cost[start] = 0;
  while (visited.size < points.length) {
    let u = -1;
    for (let i = 0; i < points.length; i++)
      if (!visited.has(i) && (u === -1 || cost[i] < cost[u])) u = i;
    if (u === -1 || !Number.isFinite(cost[u]))
      throw new Error('Onbereikbaar pad');
    if (u === goal) break;
    visited.add(u);
    for (const [x, y] of links) {
      const v = x === u ? y : y === u ? x : -1;
      if (v < 0) continue;
      const d = cost[u] + distance(points[u], points[v]);
      if (d < cost[v]) {
        cost[v] = d;
        prev[v] = u;
      }
    }
  }
  const route: Point[] = [];
  for (let u = goal; u !== -1; u = prev[u]) route.unshift(points[u]);
  return route;
}
export function advance(from: Point, to: Point, step: number): Point {
  const d = distance(from, to);
  if (d <= step) return { ...to };
  return {
    x: from.x + ((to.x - from.x) * step) / d,
    y: from.y + ((to.y - from.y) * step) / d,
  };
}
export const PLACES = [
  {
    id: 'adventure',
    x: 32.5,
    y: 26,
    icon: '🏡',
    name: 'Schooltas zoeken',
    house: 'Mijn huis',
    region: 'Onze straat',
  },
  {
    id: 'school',
    x: 81.8,
    y: 32,
    icon: '🏫',
    name: 'Leren en helpen',
    house: 'De school',
    region: 'Schoolplein',
  },
  {
    id: 'club',
    x: 25,
    y: 83,
    icon: '🏠',
    name: 'Spelletjes spelen',
    house: 'Buurthuis',
    region: 'Buurttuin',
  },
  {
    id: 'playground',
    x: 84.5,
    y: 73,
    icon: '⚽',
    name: 'Spelen en bewegen',
    house: 'Sporthuis',
    region: 'Speelveld',
  },
];
export const nearestPlace = (p: Point) =>
  PLACES.find((place) => distance(p, place) < 3.5);
export function cameraOffset(
  player: Point,
  scene: { width: number; height: number },
  viewport: { width: number; height: number },
): Point {
  return {
    x:
      scene.width <= viewport.width
        ? (viewport.width - scene.width) / 2
        : Math.max(
            viewport.width - scene.width,
            Math.min(0, viewport.width / 2 - (player.x / 100) * scene.width),
          ),
    y:
      scene.height <= viewport.height
        ? (viewport.height - scene.height) / 2
        : Math.max(
            viewport.height - scene.height,
            Math.min(0, viewport.height / 2 - (player.y / 100) * scene.height),
          ),
  };
}

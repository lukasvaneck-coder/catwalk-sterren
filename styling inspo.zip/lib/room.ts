export type RoomPoint = { x: number; y: number };
export const roomFloor = { left: 32, right: 78, top: 51, bottom: 91 };
export function clampRoom(p: RoomPoint): RoomPoint {
  return {
    x: Math.max(roomFloor.left, Math.min(roomFloor.right, p.x)),
    y: Math.max(roomFloor.top, Math.min(roomFloor.bottom, p.y)),
  };
}
export const roomDistance = (a: RoomPoint, b: RoomPoint) =>
  Math.hypot(a.x - b.x, ((a.y - b.y) * 2) / 3);
export function roomStep(a: RoomPoint, b: RoomPoint, step: number): RoomPoint {
  const goal = clampRoom(b),
    d = roomDistance(a, goal);
  return d <= step
    ? goal
    : {
        x: a.x + ((goal.x - a.x) * step) / d,
        y: a.y + ((goal.y - a.y) * step) / d,
      };
}
export const roomSpots = [
  { id: 'desk', icon: '📝', label: 'Lees het briefje', x: 77, y: 56 },
  { id: 'bed', icon: '🎒', label: 'Kijk onder het bed', x: 33, y: 72 },
  { id: 'cupboard', icon: '🔎', label: 'Kijk in de kast', x: 51, y: 51 },
];
export const roomItems = [
  { id: 'book', icon: '📗', label: 'Pak het leesboek', x: 42, y: 80 },
  { id: 'pencil', icon: '✏️', label: 'Pak het potlood', x: 76, y: 59 },
  { id: 'bottle', icon: '🧃', label: 'Pak het drinken', x: 58, y: 53 },
  { id: 'lunch', icon: '🥪', label: 'Pak de lunch', x: 70, y: 80 },
  { id: 'ball', icon: '⚽', label: 'Pak de voetbal', x: 35, y: 61 },
];
export function roomCamera(
  p: RoomPoint,
  view: { width: number; height: number },
) {
  const width = Math.max(view.width, view.height * 2.1),
    height = width / 1.5;
  return {
    width,
    height,
    x: Math.max(
      view.width - width,
      Math.min(0, view.width / 2 - (p.x / 100) * width),
    ),
    y: Math.max(
      view.height - height,
      Math.min(0, view.height * 0.58 - (p.y / 100) * height),
    ),
  };
}

import { clothingColors, hairColors, type AvatarLook } from './wardrobe';
export type Sprite = {
  canvas: HTMLCanvasElement;
  neck: number;
  feet: number;
  top: number;
};
const hex = (c: string) =>
  [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
const pink = (r: number, g: number, b: number) =>
  r - g > 35 && b - g > 12 && r > b;
const blue = (r: number, g: number, b: number) => b - r > 12 && b > g;
export function prepareSprite(
  image: CanvasImageSource & { width: number; height: number },
  index: number,
  kind: 'legacy' | 'hair' | 'clothes',
  make: () => HTMLCanvasElement,
): Sprite {
  const c = make(),
    ctx = c.getContext('2d')!;
  if (kind === 'legacy') {
    const w = image.width / 4,
      centers = [0.134, 0.375, 0.614, 0.863],
      dw = (400 * w) / image.height;
    ctx.drawImage(
      image,
      centers[index] * image.width - w / 2,
      0,
      w,
      image.height,
      (400 - dw) / 2,
      0,
      dw,
      400,
    );
  } else {
    const w = image.width / 4,
      h = image.height / 4;
    ctx.drawImage(
      image,
      (index % 4) * w,
      Math.floor(index / 4) * h,
      w,
      h,
      0,
      0,
      400,
      400,
    );
  }
  const p = ctx.getImageData(0, 0, 400, 400);
  const original = new Uint8ClampedArray(p.data);
  const seen = new Uint8Array(160000),
    queue = new Int32Array(160000);
  let head = 0,
    tail = 0;
  const visit = (n: number) => {
    if (n < 0 || n >= 160000 || seen[n]) return;
    const i = n * 4,
      r = p.data[i],
      g = p.data[i + 1],
      b = p.data[i + 2];
    if (
      p.data[i + 3] > 20 &&
      !(
        Math.max(r, g, b) - Math.min(r, g, b) < 22 &&
        !(kind === 'legacy' && n < 104000 && r - b > 7 && r - g > 3) &&
        Math.max(r, g, b) > (kind === 'legacy' ? 130 : 200)
      )
    )
      return;
    seen[n] = 1;
    queue[tail++] = n;
  };
  for (let i = 0; i < 400; i++) {
    visit(i);
    visit(159600 + i);
    visit(i * 400);
    visit(i * 400 + 399);
  }
  while (head < tail) {
    const n = queue[head++];
    p.data[n * 4 + 3] = 0;
    if (n % 400) visit(n - 1);
    if (n % 400 < 399) visit(n + 1);
    visit(n - 400);
    visit(n + 400);
  }
  if (kind === 'legacy')
    for (let y = 200; y < 400; y++)
      for (let x = 0; x < 400; x++) {
        const i = (y * 400 + x) * 4,
          r = p.data[i],
          g = p.data[i + 1],
          b = p.data[i + 2];
        if (
          Math.max(r, g, b) - Math.min(r, g, b) < 22 &&
          Math.max(r, g, b) > 130 &&
          !(y < 260 && r - b > 7 && r - g > 3)
        )
          p.data[i + 3] = 0;
      }
  let neck = 180,
    feet = 380,
    top = 400;
  for (let y = 0; y < 400; y++)
    for (let x = 0; x < 400; x++) {
      const i = (y * 400 + x) * 4;
      if (p.data[i + 3] > 100) {
        top = Math.min(top, y);
        if (
          y > 300 &&
          (pink(p.data[i], p.data[i + 1], p.data[i + 2]) ||
            blue(p.data[i], p.data[i + 1], p.data[i + 2]))
        )
          feet = Math.max(feet, y);
      }
    }
  outer: for (let y = 140; y < 260; y++) {
    let count = 0;
    for (let x = 193; x < 207; x++) {
      const i = (y * 400 + x) * 4,
        r = p.data[i],
        g = p.data[i + 1],
        b = p.data[i + 2];
      if (pink(r, g, b) || blue(r, g, b) || (g - r > 20 && g - b > 10)) count++;
    }
    if (count > 7) {
      neck = y;
      break outer;
    }
  }
  if (kind === 'clothes') neck = 179;
  // Preserve white sneaker soles connected to the white atlas background.
  for (let y = 330; y < 400; y++)
    for (const [left, right] of [
      [80, 199],
      [200, 320],
    ]) {
      let low = 400,
        high = 0;
      for (let yy = Math.max(330, y - 4); yy <= Math.min(399, y + 4); yy++)
        for (let x = left; x <= right; x++) {
          const i = (yy * 400 + x) * 4;
          if (pink(original[i], original[i + 1], original[i + 2])) {
            low = Math.min(low, x);
            high = Math.max(high, x);
          }
        }
      for (let x = low; x <= high; x++) {
        const i = (y * 400 + x) * 4;
        if (
          original[i] > 195 &&
          Math.max(original[i], original[i + 1], original[i + 2]) -
            Math.min(original[i], original[i + 1], original[i + 2]) <
            25
        ) {
          p.data[i] = original[i];
          p.data[i + 1] = original[i + 1];
          p.data[i + 2] = original[i + 2];
          p.data[i + 3] = 255;
        }
      }
    }
  ctx.putImageData(p, 0, 0);
  return { canvas: c, neck, feet, top };
}
// Atlas jackets share their blue with the source trousers. Exclude those
// trousers geometrically so the player's chosen bottom remains visible.
export function jacketFabricRegion(
  x: number,
  y: number,
  neck: number,
  jacket: number,
): boolean {
  if (y < neck - 12 || y >= neck + (jacket === 3 ? 132 : 84)) return false;
  const openingStarts = neck + 61;
  const openingWidth =
    28 + Math.max(0, y - (neck + 65)) * (jacket === 3 ? 0.15 : 0);
  return !(y >= openingStarts && Math.abs(x - 200) < openingWidth);
}
export function composeAvatar(
  look: AvatarLook,
  headSprite: Sprite,
  clothes: Sprite[],
  dress: Sprite,
  make: () => HTMLCanvasElement,
): HTMLCanvasElement {
  const out = make(),
    ctx = out.getContext('2d')!;
  function layer(
    sprite: Sprite,
    part: 'head' | 'dress' | 'top' | 'bottom' | 'jacket' | 'shoes',
    color: number,
  ) {
    const c = make(),
      g = c.getContext('2d')!;
    g.drawImage(sprite.canvas, 0, 0);
    const p = g.getImageData(0, 0, 400, 400),
      target = hex(
        part === 'head' ? hairColors[color][1] : clothingColors[color][1],
      );
    const neck = sprite.neck,
      waist = neck + 65,
      shoeStart =
        sprite.feet - (look.shoes === 1 ? 59 : look.shoes === 2 ? 65 : 39);
    for (let y = 0; y < 400; y++)
      for (let x = 0; x < 400; x++) {
        const i = (y * 400 + x) * 4;
        if (p.data[i + 3] < 20) continue;
        const r = p.data[i],
          gg = p.data[i + 1],
          b = p.data[i + 2],
          max = Math.max(r, gg, b),
          min = Math.min(r, gg, b);
        const hair = max - min < 75 && max < 210 && r >= b;
        let keep = true,
          tint = false;
        if (part === 'head') {
          const eyeY = neck - (look.hairStyle < 4 ? 57 : 75);
          const face =
            ((x - 168) / 23) ** 2 + ((y - eyeY) / 23) ** 2 < 1 ||
            ((x - 232) / 23) ** 2 + ((y - eyeY) / 23) ** 2 < 1 ||
            (x > 180 && x < 220 && y > neck - 38 && y < neck - 7);
          keep = (y < neck && !pink(r, gg, b)) || (hair && y < neck + 110);
          if (y > neck - 18 && Math.abs(x - 200) > 28 && !hair) keep = false;
          tint = hair && !face;
        }
        if (part === 'dress') {
          keep = y >= neck - 12;
          if (y > sprite.feet - 45 && pink(r, gg, b)) keep = false;
          tint = pink(r, gg, b);
        }
        if (part === 'top') {
          keep = y >= neck - 12 && y < waist + 3;
          tint = pink(r, gg, b);
          if (blue(r, gg, b) && y > waist - 12) keep = false;
        }
        if (part === 'bottom') {
          keep = y >= waist - 6;
          tint = blue(r, gg, b);
          if (pink(r, gg, b) || (y > sprite.feet - 45 && max - min < 25))
            keep = false;
        }
        if (
          look.jacket &&
          (part === 'top' || part === 'bottom' || part === 'dress')
        ) {
          const skin = r > gg * 1.15 && gg > b * 1.05 && r - b > 35;
          const arm =
            Math.abs(x - 200) > 43 && y >= neck - 12 && y < neck + 115;
          if (arm && (part === 'top' || skin)) keep = false;
        }
        if (part === 'jacket') {
          const skin = r > gg * 1.15 && gg > b * 1.05 && r - b > 35;
          const hand =
            skin && Math.abs(x - 200) > 55 && y >= neck + 43 && y < neck + 110;
          keep =
            (jacketFabricRegion(x, y, neck, look.jacket) && blue(r, gg, b)) ||
            hand;
          tint = blue(r, gg, b);
        }
        if (part === 'shoes') {
          keep = y >= shoeStart && !blue(r, gg, b);
          tint = pink(r, gg, b);
        }
        if (part !== 'head' && y < neck + 30 && hair) keep = false;
        if (!keep) {
          p.data[i + 3] = 0;
          continue;
        }
        if (tint) {
          const shade =
            part === 'head'
              ? 0.35 + (r + gg + b) / 450
              : (r + gg + b) /
                (part === 'bottom' || part === 'jacket' ? 310 : 490);
          for (let k = 0; k < 3; k++)
            p.data[i + k] = Math.min(255, target[k] * shade);
        }
      }
    g.putImageData(p, 0, 0);
    if (part === 'head') {
      const scale = Math.min(1, 170 / (neck - sprite.top));
      ctx.drawImage(
        c,
        200 - 200 * scale,
        180 - neck * scale,
        400 * scale,
        400 * scale,
      );
    } else {
      const scale = 210 / (sprite.feet - neck);
      ctx.drawImage(
        c,
        200 - 200 * scale,
        180 - neck * scale,
        400 * scale,
        400 * scale,
      );
    }
  }
  layer(headSprite, 'head', look.hairColor);
  if (look.outfit === 'dress') layer(dress, 'dress', look.color);
  else {
    layer(clothes[look.bottom + 4], 'bottom', look.bottomColor);
    layer(clothes[look.top], 'top', look.topColor);
  }
  if (look.jacket) layer(clothes[look.jacket + 11], 'jacket', look.jacketColor);
  layer(clothes[look.shoes + 12], 'shoes', look.shoeColor);
  return out;
}

export const hairStyles = [
  'Boblijn',
  'Twee staartjes',
  'Krullen',
  'Hoge knot',
  'Pixie',
  'Lang & steil',
  'Lange golven',
  'Hoge paardenstaart',
  'Zijstaart',
  'Twee vlechten',
  'Zijvlecht',
  'Vlechtkroon',
  'Afrokrullen',
  'Twee afrobolletjes',
  'Twee knotjes',
  'Korte krullen',
  'Bob met pony',
  'Lang met pony',
  'Half opgestoken',
  'Lage knot',
];
export const hairColors = [
  ['Bruin', '#70422a'],
  ['Blond', '#e5b956'],
  ['Zwart', '#292333'],
  ['Rood', '#ba542d'],
  ['Roze', '#db65a5'],
  ['Paars', '#9064c5'],
];
export const clothingColors = [
  ['Roze', '#ed5a9c'],
  ['Lila', '#ac72e6'],
  ['Hemelsblauw', '#55b3e3'],
  ['Mint', '#61caac'],
  ['Zonneschijn', '#eac84d'],
  ['Spijkerblauw', '#3b77a6'],
  ['Koraal', '#eb7657'],
  ['Roomwit', '#e8e3d5'],
];
export const topStyles = ['T-shirt', 'Strepenshirt', 'Lange mouwen', 'Blouse'];
export const bottomStyles = [
  'Spijkerbroek',
  'Korte broek',
  'Wijde broek',
  'Legging',
  'Zwierig rokje',
  'Plooirokje',
  'Rokje met ruches',
  'Spijkerrokje',
];
export const jacketStyles = [
  'Geen jasje',
  'Spijkerjasje',
  'Vest met capuchon',
  'Lange jas',
];
export const shoeStyles = [
  'Sneakers',
  'Regenlaarsjes',
  'Hoge laarzen',
  'Bandschoentjes',
];
export type AvatarLook = {
  color: number;
  extra: string;
  hairStyle: number;
  hairColor: number;
  outfit: 'dress' | 'separates';
  top: number;
  bottom: number;
  jacket: number;
  shoes: number;
  topColor: number;
  bottomColor: number;
  jacketColor: number;
  shoeColor: number;
};
export const lookDefaults: AvatarLook = {
  color: 0,
  extra: 'bow',
  hairStyle: 0,
  hairColor: 0,
  outfit: 'dress',
  top: 0,
  bottom: 0,
  jacket: 0,
  shoes: 3,
  topColor: 0,
  bottomColor: 5,
  jacketColor: 5,
  shoeColor: 0,
};
export function normalizeLook(raw: unknown): AvatarLook {
  const s = (raw && typeof raw === 'object' ? raw : {}) as Record<
    string,
    unknown
  >;
  const n = (key: keyof AvatarLook, size: number) =>
    Number.isInteger(s[key]) && Number(s[key]) >= 0 && Number(s[key]) < size
      ? Number(s[key])
      : Number(lookDefaults[key]);
  return {
    color: n('color', clothingColors.length),
    extra: ['none', 'bow', 'flower', 'crown', 'butterfly'].includes(
      String(s.extra),
    )
      ? String(s.extra)
      : 'bow',
    hairStyle: n('hairStyle', hairStyles.length),
    hairColor: n('hairColor', hairColors.length),
    outfit: s.outfit === 'separates' ? 'separates' : 'dress',
    top: n('top', topStyles.length),
    bottom: n('bottom', bottomStyles.length),
    jacket: n('jacket', jacketStyles.length),
    shoes: n('shoes', shoeStyles.length),
    topColor: n('topColor', clothingColors.length),
    bottomColor: n('bottomColor', clothingColors.length),
    jacketColor: n('jacketColor', clothingColors.length),
    shoeColor: n('shoeColor', clothingColors.length),
  };
}

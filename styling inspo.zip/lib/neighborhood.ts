export const phases = [
  'intro',
  'search',
  'pack',
  'journey',
  'school',
  'reward',
  'done',
] as const;
export type Phase = (typeof phases)[number];
export type NeighborhoodSave = {
  phase: Phase;
  group: 3 | 5;
  completed: boolean;
  garden: 'none' | 'flowers' | 'tree' | 'bench';
  playground: 'none' | 'swings' | 'seesaw' | 'climber';
};
export const defaultNeighborhood: NeighborhoodSave = {
  phase: 'intro',
  group: 3,
  completed: false,
  garden: 'none',
  playground: 'none',
};
export function normalizeNeighborhood(raw: unknown): NeighborhoodSave {
  const s = (raw && typeof raw === 'object' ? raw : {}) as Record<
    string,
    unknown
  >;
  const completed = s.completed === true;
  return {
    phase:
      s.phase === 'done' && !completed
        ? 'intro'
        : phases.includes(s.phase as Phase)
          ? (s.phase as Phase)
          : 'intro',
    group: s.group === 5 ? 5 : 3,
    completed,
    garden:
      completed && ['flowers', 'tree', 'bench'].includes(String(s.garden))
        ? (s.garden as NeighborhoodSave['garden'])
        : 'none',
    playground:
      completed &&
      ['swings', 'seesaw', 'climber'].includes(String(s.playground))
        ? (s.playground as NeighborhoodSave['playground'])
        : 'none',
  };
}
export function claimNeighborhoodReward<
  T extends { stars: number; neighborhood: NeighborhoodSave },
>(save: T): T {
  if (save.neighborhood.phase !== 'reward') return save;
  return {
    ...save,
    stars: save.stars + (save.neighborhood.completed ? 0 : 8),
    neighborhood: { ...save.neighborhood, phase: 'done', completed: true },
  };
}
export const missionLabels: Record<Phase, string> = {
  intro: 'De verdwenen schooltas',
  search: 'Zoek je schooltas',
  pack: 'Pak de schoolspullen in',
  journey: 'Over de plassen naar school',
  school: 'Help in de klas',
  reward: 'Haal je beloning op',
  done: 'Maak jouw buurt mooier',
};
export const gardenItems = [
  { id: 'flowers', name: 'Bloembak', index: 0 },
  { id: 'tree', name: 'Fruitboompje', index: 1 },
  { id: 'bench', name: 'Tuinbankje', index: 2 },
] as const;
export const playgroundItems = [
  { id: 'swings', name: 'Schommels', index: 3 },
  { id: 'seesaw', name: 'Wipwap', index: 4 },
  { id: 'climber', name: 'Klimrek', index: 5 },
] as const;
export const puddles = [180, 390, 620, 850, 1090];
export function jumpHeight(seconds: number) {
  return seconds < 0 || seconds > 0.95
    ? 0
    : Math.sin((seconds / 0.95) * Math.PI) * 100;
}
export function crossedPuddle(from: number, to: number, jump: number) {
  return puddles.some((p) => from < p && to >= p) && jump < 35;
}
export const schoolAnswers = (group: 3 | 5) => ({
  word: group === 3 ? 'tas' : 'school',
  plates: group === 3 ? 3 : 4,
  each: group === 3 ? 2 : 3,
});

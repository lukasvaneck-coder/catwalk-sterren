import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const source = ts.transpileModule(
  fs.readFileSync('lib/neighborhood.ts', 'utf8'),
  {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ES2022,
    },
  },
).outputText;
const {
  defaultNeighborhood,
  normalizeNeighborhood,
  claimNeighborhoodReward,
  jumpHeight,
  crossedPuddle,
  puddles,
  schoolAnswers,
} = await import(
  'data:text/javascript;base64,' + Buffer.from(source).toString('base64')
);
test('legacy saves start a new mission and cannot have locked decorations', () => {
  assert.deepEqual(normalizeNeighborhood(undefined), defaultNeighborhood);
  assert.equal(
    normalizeNeighborhood({ garden: 'tree', phase: 'done' }).garden,
    'none',
  );
  assert.equal(normalizeNeighborhood({ phase: 'done' }).phase, 'intro');
});
test('completed neighborhood and replay phase survive a roundtrip', () => {
  const s = {
    phase: 'pack',
    group: 5,
    completed: true,
    garden: 'tree',
    playground: 'climber',
  };
  assert.deepEqual(normalizeNeighborhood(JSON.parse(JSON.stringify(s))), s);
});
test('claiming and replaying the mission cannot award the stars twice', () => {
  const start = {
    stars: 17,
    name: 'Meisje',
    neighborhood: { ...defaultNeighborhood, phase: 'reward' },
  };
  const won = claimNeighborhoodReward(start);
  assert.equal(won.stars, 25);
  assert.equal(won.neighborhood.completed, true);
  assert.equal(won.name, 'Meisje');
  assert.deepEqual(claimNeighborhoodReward(won), won);
  assert.equal(
    claimNeighborhoodReward({
      ...won,
      neighborhood: { ...won.neighborhood, phase: 'reward' },
    }).stars,
    25,
  );
  assert.equal(start.stars, 17);
});
test('every puddle can be jumped at both speeds and walking into it fails', () => {
  for (const speed of [90, 120])
    for (const p of puddles) {
      assert.equal(crossedPuddle(p - 1, p + 1, 0), true);
      const height = jumpHeight(40 / speed);
      assert.equal(crossedPuddle(p - 1, p + 1, height), false);
    }
  assert.equal(jumpHeight(1), 0);
  assert.equal(jumpHeight(-1), 0);
  assert.equal(crossedPuddle(0, 100, 0), false);
});
test('school puzzles offer different word lengths and fruit counts', () => {
  assert.deepEqual(schoolAnswers(3), { word: 'tas', plates: 3, each: 2 });
  assert.deepEqual(schoolAnswers(5), { word: 'school', plates: 4, each: 3 });
});

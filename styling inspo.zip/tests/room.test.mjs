import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const source = ts.transpileModule(fs.readFileSync('lib/room.ts', 'utf8'), {
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.ES2022,
  },
}).outputText;
const {
  roomFloor,
  clampRoom,
  roomStep,
  roomDistance,
  roomSpots,
  roomItems,
  roomCamera,
} = await import(
  'data:text/javascript;base64,' + Buffer.from(source).toString('base64')
);
test('every room interaction can be reached without entering furniture', () => {
  for (const from of [...roomSpots, ...roomItems])
    for (const to of [...roomSpots, ...roomItems]) {
      let p = clampRoom(from),
        steps = 0;
      while (roomDistance(p, to) > 0.001) {
        p = roomStep(p, to, 0.3);
        assert.ok(p.x >= roomFloor.left && p.x <= roomFloor.right);
        assert.ok(p.y >= roomFloor.top && p.y <= roomFloor.bottom);
        assert.ok(++steps < 400);
      }
      assert.ok(roomDistance(p, to) < 4.5);
    }
});
test('room movement clamps outside taps and never overshoots', () => {
  assert.deepEqual(clampRoom({ x: -200, y: 300 }), { x: 32, y: 91 });
  assert.deepEqual(roomStep({ x: 50, y: 70 }, { x: 52, y: 72 }, 100), {
    x: 52,
    y: 72,
  });
  assert.ok(
    Math.abs(
      roomDistance(
        { x: 50, y: 70 },
        roomStep({ x: 50, y: 70 }, { x: 70, y: 90 }, 1),
      ) - 1,
    ) < 1e-9,
  );
});
test('portrait and landscape cameras cover the viewport and retain the avatar on rotation', () => {
  for (const view of [
    { width: 360, height: 740 },
    { width: 390, height: 844 },
    { width: 844, height: 390 },
    { width: 1024, height: 768 },
  ])
    for (const p of [...roomSpots, ...roomItems, { x: 53, y: 85 }]) {
      const c = roomCamera(p, view);
      assert.ok(c.x <= 0 && c.y <= 0);
      assert.ok(
        c.x + c.width >= view.width - 1e-9 &&
          c.y + c.height >= view.height - 1e-9,
      );
      const x = (p.x / 100) * c.width + c.x,
        y = (p.y / 100) * c.height + c.y;
      assert.ok(x > 0 && x < view.width);
      assert.ok(y > 0 && y < view.height);
    }
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const compile = (s) =>
  ts.transpileModule(s, {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ES2022,
    },
  }).outputText;
const url = (s) =>
  'data:text/javascript;base64,' + Buffer.from(s).toString('base64');
const wardUrl = url(compile(fs.readFileSync('lib/wardrobe.ts', 'utf8')));
const {
  hairStyles,
  topStyles,
  bottomStyles,
  jacketStyles,
  shoeStyles,
  lookDefaults,
  normalizeLook,
} = await import(wardUrl);
const neighborhoodUrl = url(
  compile(fs.readFileSync('lib/neighborhood.ts', 'utf8')),
);
const { defaultNeighborhood } = await import(neighborhoodUrl);
const page = fs.readFileSync('app/page.tsx', 'utf8');
const chunk = page.slice(
  page.indexOf('const extras ='),
  page.indexOf('function say('),
);
const { readSave } = await import(
  url(
    compile(
      `import {defaultNeighborhood,normalizeNeighborhood} from '${neighborhoodUrl}'; import {lookDefaults,normalizeLook} from '${wardUrl}';\n${chunk}\nexport {readSave};`,
    ),
  )
);
test('twenty distinct hairstyles and all requested clothing categories exist', () => {
  assert.equal(hairStyles.length, 20);
  assert.equal(new Set(hairStyles).size, 20);
  assert.equal(topStyles.length, 4);
  assert.equal(bottomStyles.length, 8);
  assert.equal(jacketStyles.length, 4);
  assert.equal(shoeStyles.length, 4);
});
test('older progress keeps hairstyle, dress, stars and unlocked accessories', () => {
  const s = readSave(
    JSON.stringify({
      name: 'Ster',
      stars: 43,
      hairStyle: 3,
      hairColor: 4,
      color: 2,
      extra: 'crown',
      unlocked: ['none', 'bow', 'crown'],
      hard: true,
    }),
  );
  assert.equal(s.stars, 43);
  assert.equal(s.name, 'Ster');
  assert.equal(s.extra, 'crown');
  assert.equal(s.hairStyle, 3);
  assert.equal(s.hairColor, 4);
  assert.equal(s.color, 2);
  assert.equal(s.outfit, 'dress');
  assert.equal(s.hard, true);
  assert.equal(s.jacket, 0);
});
test('a complete mixed outfit and new hairstyle survive saving and reloading', () => {
  const s = {
    ...lookDefaults,
    name: 'Vlinder',
    neighborhood: defaultNeighborhood,
    stars: 21,
    unlocked: ['none', 'bow'],
    hard: false,
    hairStyle: 19,
    outfit: 'separates',
    top: 3,
    bottom: 7,
    jacket: 3,
    shoes: 2,
    topColor: 7,
    bottomColor: 5,
    jacketColor: 3,
    shoeColor: 4,
  };
  assert.deepEqual(readSave(JSON.stringify(s)), s);
});
test('malformed and out of range saved choices get usable defaults', () => {
  assert.deepEqual(normalizeLook(null), lookDefaults);
  for (const field of [
    'hairStyle',
    'hairColor',
    'color',
    'top',
    'bottom',
    'jacket',
    'shoes',
    'topColor',
    'bottomColor',
    'jacketColor',
    'shoeColor',
  ])
    for (const value of [-1, 500, '2', null, 1.3])
      assert.equal(
        normalizeLook({ [field]: value })[field],
        lookDefaults[field],
      );
  assert.equal(readSave('{broken').stars, 0);
  assert.equal(
    readSave(JSON.stringify({ stars: -3, extra: 'crown', unlocked: [] })).extra,
    'bow',
  );
});

test('jackets do not include source trousers below the open front or hem', async () => {
  const rendererSource = compile(
    fs.readFileSync('lib/avatar-renderer.ts', 'utf8'),
  ).replace("'./wardrobe'", JSON.stringify(wardUrl));
  const { jacketFabricRegion } = await import(url(rendererSource));
  for (const jacket of [1, 2, 3]) {
    assert.equal(jacketFabricRegion(200, 250, 179, jacket), false);
    assert.equal(jacketFabricRegion(165, 320, 179, jacket), false);
    assert.equal(jacketFabricRegion(155, 225, 179, jacket), true);
  }
  assert.equal(jacketFabricRegion(150, 289, 179, 3), true);
  assert.equal(jacketFabricRegion(150, 289, 179, 1), false);
});

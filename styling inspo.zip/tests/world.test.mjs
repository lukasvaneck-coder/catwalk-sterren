import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const source = ts.transpileModule(fs.readFileSync('lib/world.ts', 'utf8'), {
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.ES2022,
  },
}).outputText;
const {
  PATH,
  PATH_RADIUS,
  PLACES,
  advance,
  distance,
  projectToPath,
  constrainToPath,
  routeTo,
  nearestPlace,
  cameraOffset,
} = await import(
  'data:text/javascript;base64,' + Buffer.from(source).toString('base64')
);
function walk(from, to) {
  let p = from;
  for (const waypoint of routeTo(from, to)) {
    let steps = 0;
    while (distance(p, waypoint) > 1e-9) {
      p = advance(p, waypoint, 0.2);
      assert.ok(projectToPath(p).distance < 0.001);
      assert.ok(++steps < 1000);
      assert.ok(
        !(p.x > 12 && p.x < 29 && p.y > 69 && p.y < 78),
        'Route intersects community center',
      );
      assert.ok(
        !(p.x > 81 && p.x < 91 && p.y > 63 && p.y < 68),
        'Route intersects sports shed',
      );
    }
  }
  return p;
}
test('all four building entrances are reachable from every building', () => {
  for (const a of PLACES)
    for (const b of PLACES) assert.equal(nearestPlace(walk(a, b))?.id, b.id);
});
test('the sidewalks, field, and every junction connect to every building', () => {
  for (const node of PATH)
    for (const place of PLACES)
      assert.equal(nearestPlace(walk(node, place))?.id, place.id);
});
test('route finding uses the short upper path between upper buildings', () => {
  const route = routeTo(PLACES[0], PLACES[1]);
  assert.ok(route.every((p) => p.y <= 40));
  assert.ok(
    route.reduce((sum, p, i) => sum + (i ? distance(route[i - 1], p) : 0), 0) <
      60,
  );
});
test('walking stays within path boundaries', () => {
  for (const p of [
    { x: -500, y: 500 },
    { x: 90, y: 10 },
    { x: 30, y: 70 },
    { x: 75, y: 70 },
    { x: 99, y: 60 },
  ])
    assert.ok(projectToPath(constrainToPath(p)).distance <= PATH_RADIUS + 1e-6);
});
test('movement never overshoots and diagonal movement has equal speed', () => {
  assert.deepEqual(advance({ x: 1, y: 1 }, { x: 2, y: 2 }, 100), {
    x: 2,
    y: 2,
  });
  assert.ok(
    Math.abs(
      distance({ x: 0, y: 0 }, advance({ x: 0, y: 0 }, { x: 10, y: 15 }, 1)) -
        1,
    ) < 1e-9,
  );
});
test('camera follows the avatar and never reveals space outside the world', () => {
  const scene = { width: 2400, height: 1600 },
    view = { width: 1000, height: 550 };
  assert.deepEqual(cameraOffset({ x: 50, y: 50 }, scene, view), {
    x: -700,
    y: -525,
  });
  assert.deepEqual(cameraOffset({ x: 0, y: 0 }, scene, view), { x: 0, y: 0 });
  assert.deepEqual(cameraOffset({ x: 100, y: 100 }, scene, view), {
    x: -1400,
    y: -1050,
  });
});
test('overview centers the whole village on tablet and desktop', () => {
  for (const view of [
    { width: 360, height: 450 },
    { width: 1160, height: 600 },
  ]) {
    const width = Math.min(view.width, view.height * 1.5),
      height = (width * 2) / 3;
    const offset = cameraOffset({ x: 80, y: 80 }, { width, height }, view);
    assert.ok(offset.x >= 0 && offset.y >= 0);
    assert.ok(offset.x + width <= view.width);
    assert.ok(offset.y + height <= view.height);
  }
});

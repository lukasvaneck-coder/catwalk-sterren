# Sterreneiland

Eerste speelbare versie voor kinderen van 5 en 8. Nederlands, geschikt voor aanraken, muis en toetsenbord.

- Verkleedkamer: vijf kleuren, vijf accessoirekeuzes, eigen speelnaam.
- Sterren vangen: 15 sterren, rustige of snelle stand, toetsen 1–9.
- Memory: vier of zes paren, zonder tijdslimiet.
- Dansfeest: drie steeds langere reeksen, pijltjestoetsen of knoppen, onbeperkt opnieuw kijken.
- Sterren en outfits blijven in localStorage op dit apparaat/browser. Geen synchronisatie of multiplayer. Wissen van browsergegevens verwijdert voortgang.
- Voorlezen gebruikt de beschikbare Nederlandse browserstem; beschikbaarheid verschilt per apparaat.

## Ontwikkelen

`npm install`, `npm run dev`, `npm run build`.

Statische uitvoer: `dist/client`. `scripts/build.mjs` geeft op Windows native handles tijd om af te sluiten en behoudt de originele build-exitcode.

Validatie: TypeScript zonder fouten en geslaagde productiebuild. Nog niet interactief getest in een browser. Optionele WebMCP-navigatie is alleen beschikbaar wanneer de browser document.modelContext aanbiedt; het contract is hier niet in een ondersteunde context getest.

Illustraties zijn origineel gegenereerd voor deze game. De pop wordt tijdens het spelen lokaal ingekleurd.

## Avatar en wandelwereld (versie 2)

Vier kapsels, zes haarkleuren en de bestaande jurken/accessoires verschijnen op dezelfde avatar in de editor en op het eiland. Nieuwe spelers beginnen in de avatar-editor. Bestaande opslag wordt uitgebreid met standaard haarinstellingen zonder sterren of accessoires te verliezen.

Lopen: pijltjes, WASD, de loopknoppen of tikken op het pad. Tik op een spelbord om via het pad naar die plek te wandelen; open bij aankomst met de speelknop, Enter of E. Terugkeren uit een spel bewaart de plek zolang de pagina open blijft. De uitklapbare snelkeuzes blijven beschikbaar voor spelers die direct willen beginnen.

Padlogica: `node --test tests/world.test.mjs` controleert alle routes tussen de vier bestemmingen, padbegrenzing, bewegingssnelheid en omkeren. Acht avatarcombinaties zijn apart gerenderd en visueel gecontroleerd. Geen interactieve browsertest uitgevoerd.

## Dorpswereld (versie 3)

Het speelgebied is nu een groter dorp met een eigen huis voor elk spel en een apart verkleedhuis. De camera volgt het poppetje; Hele dorp toont de overzichtskaart. Vier bestemmingsknoppen laten de avatar naar een huis lopen. Elke spelruimte heeft de naam en kleuren van het bijbehorende huis.

De nieuwe kaart heeft een verbonden netwerk van paden rond het bloemenplein en een bospaadje. Dijkstra-routeplanning kiest een korte route over het netwerk, inclusief de echte deurposities. Paden lopen om de onderste huisjes heen. Zeven tests controleren alle bestemmingen vanaf alle kruispunten, obstakels, kortste route, snelheden, grenzen en camera/overzicht op desktop en tablet.

Validatie: geslaagde TypeScript-controle en productiebuild. Kaartillustratie bekeken; geen interactieve browsertest uitgevoerd.

## Uitgebreide verkleedkamer (versie 4)

20 kapsels (16 erbij), 4 shirts, 4 broeken, 4 rokjes, 3 jasjes plus geen jasje, en 4 schoenkeuzes. Losse kledingdelen hebben elk hun eigen kleur. De feestjurk blijft een alternatief; jasjes en schoenen kunnen ook bij de jurk. De nieuwe kleding en kapsels zijn direct beschikbaar.

`lib/wardrobe.ts` beheert keuzes en migratie van oudere opgeslagen avatars. `lib/avatar-renderer.ts` combineert de gegenereerde illustraties tot dezelfde avatar voor de editor en de wandelwereld. Sprite-atlassen worden eenmaal geladen; samengestelde avatars worden begrensd gecachet.

11 tests geslaagd (`node --test tests/world.test.mjs tests/wardrobe.test.mjs`), TypeScript-controle en productiebuild geslaagd. Twaalf samengestelde outfits apart gerenderd en visueel gecontroleerd. Alle 20 kapsels en alle kledingopties geven elk een verschillende gerenderde afbeelding. Geen interactieve browsertest uitgevoerd.
